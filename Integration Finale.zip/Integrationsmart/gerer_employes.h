#ifndef GERER_EMPLOYES_H
#define GERER_EMPLOYES_H

#include <QDialog>
#include "employe.h"
#include <QDebug>
#include <QMessageBox>
#include "statistiques.h"
#include "arduino.h"
namespace Ui {
class gerer_employes;
}

class gerer_employes : public QDialog
{
    Q_OBJECT

public:
    explicit gerer_employes(QWidget *parent = nullptr);
    ~gerer_employes();
    QString role,nom_u;
private slots :
    void on_pb_ajout_em_clicked();

    void on_pb_stat_clicked();

    void on_search_pb_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_pushButton_11_clicked();

    void concatRfid();
    void updateLabel(QString,QString);

    void on_pb_modif_emp_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_10_clicked();

    void on_pb_supprimer_employe_clicked();

    bool controlSalaire(int test);

    bool controlId(int test);

    bool controlVide(QString test);

    bool controlEmail(QString test);
private:
    Ui::gerer_employes *ui;
    Employee C;
    QByteArray data;
        Arduino A;
        QString uid;

};

#endif // GERER_EMPLOYES_H
