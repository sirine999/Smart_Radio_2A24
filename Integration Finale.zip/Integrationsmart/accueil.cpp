#include "accueil.h"
#include "ui_accueil.h"
#include "gerer_programmes.h"
#include "gerer_materiel.h"
#include "gerer_employes.h"
#include "reclamation_workspace.h"
#include "dialoginvite.h"
accueil::accueil(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::accueil)
{
    ui->setupUi(this);
    setWindowFlags(windowFlags() | Qt::WindowTitleHint | Qt::CustomizeWindowHint | Qt::WindowMinimizeButtonHint | Qt::WindowMaximizeButtonHint);
}

accueil::~accueil()
{
    delete ui;
}
void accueil::setData(QString nomU,QString typeU)
{
    role=typeU;
    nom_u=nomU;
    if(typeU=="Employe")
    {
        ui->pushButton_employes->hide();
        ui->label_2->setText("Welcome "+nomU);
    }
    else{
        ui->label_2->setText("Welcome "+nomU);
    }
}


void accueil::on_pushButton_programmes_clicked()
{
    gerer_programmes g_p;
    g_p.role=role;
    g_p.nom_u=nom_u;
    hide();
    g_p.setModal(true);
    g_p.exec();
}



void accueil::on_pushButton_materiaux_clicked()
{
    gerer_materiel g_m;
    g_m.role=role;
    g_m.nom_u=nom_u;
    hide();
    g_m.setModal(true);
    g_m.exec();
}

void accueil::on_pushButton_employes_clicked()
{

    gerer_employes g_m;
    g_m.role=role;
    g_m.nom_u=nom_u;
    hide();
    g_m.setModal(true);
    g_m.exec();

}

void accueil::on_pushButton_reclamations_clicked()
{
    close();
 reclamation_workspace *rw= new reclamation_workspace();
 rw->show();
}

void accueil::on_pushButton_invites_clicked()
{
        hide();

    DialogInvite d ;
    d.setData(nom_u,role),
    d.exec();
}
