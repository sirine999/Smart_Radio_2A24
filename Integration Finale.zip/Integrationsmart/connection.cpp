#include "connection.h"

Connection::Connection()
{

}

bool Connection::createconnection()
{bool test=false;
db = QSqlDatabase::addDatabase("QODBC");
/*db.setDatabaseName("test");
db.setUserName("Ghassen");//inserer nom de l'utilisateur
db.setPassword("0000");//inserer mot de passe de cet utilisateur
*/

db.setDatabaseName("test");//inserer le nom de la source de données ODBC
db.setUserName("system");//inserer nom de l'utilisateur
db.setPassword("0000");//inserer mot de passe de cet utilisateur

//db.setDatabaseName("proj");
//db.setUserName("revolver");//inserer nom de l'utilisateur
//db.setPassword("revolver");//inserer mot de passe de cet utilisateur
if (db.open())
test=true;

return  test;
}

void Connection::closeconnection(){db.close();}
