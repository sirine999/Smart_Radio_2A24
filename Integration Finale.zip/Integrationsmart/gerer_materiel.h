#ifndef GERER_MATERIEL_H
#define GERER_MATERIEL_H
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include"materiel.h"
#include <QString>
#include <QSqlQuery>
#include<QtDebug>
#include<QObject>
#include<QDateTime>
#include<QPrinter>
#include<QPainter>
#include<QtCharts>
#include<QChartView>
#include"calculer.h"
#include"arduino.h"
#include <QWidget>
#include <QDialog>
#include"scenario.h"
namespace Ui {
class gerer_materiel;
}

class gerer_materiel : public QDialog
{
    Q_OBJECT

public:
    explicit gerer_materiel(QWidget *parent = nullptr);
    ~gerer_materiel();
    QString role,nom_u;


private slots:

    void stat();
    void on_pb_ajouter_clicked();

    void on_pb_supprimer_clicked();

    void on_pb_modif_clicked();



    void on_pushButton_trie_clicked();

    void on_pushButton_Recherche_clicked();

    void on_tab_materiel_activated(const QModelIndex &index);

    int on_pdf_clicked();




    void on_pb_qr_clicked();

    void on_inserer_image_clicked();



    int on_pb_pdf1_clicked();



    void on_calcul_clicked();


    void on_on_clicked();

    void on_pushButton_retour_clicked();

private:
    Ui::gerer_materiel *ui;
    Materiel m;
    Calculer *calc;
    scenario *s;


};

#endif // GERER_MATERIEL_H
