#ifndef DIALOGINVITE_H
#define DIALOGINVITE_H
#include "arduino.h"
#include <QMainWindow>
#include "invite.h"
#include "notification.h"
#include "calendrier.h"
#include <QDialog>

namespace Ui {
class DialogInvite;
}

class DialogInvite : public QDialog
{
    Q_OBJECT

public:
    explicit DialogInvite(QWidget *parent = nullptr);
    ~DialogInvite();

private slots:
    void on_pushButton_13_clicked();


    void on_ajoutaff_clicked();

    void on_confirmerajout_clicked();

    void on_annulerajout_clicked();

    void on_sup_clicked();

    void on_confirmersup_clicked();


    void on_modif_clicked();

    void on_modifier_clicked();


    void on_annulermodif_clicked();

    void on_capture_clicked();

    void on_comboBox_currentIndexChanged(int index);

    void on_pushButton_21_clicked();




    void on_rech_textChanged(const QString &arg1);

    void on_dateAjout_userDateChanged(const QDate &date);

    void on_calendrier_clicked();

    void on_pushButton_clicked();

    void on_dateEdit_userDateChanged(const QDate &date);
    void  update_label();

    void on_pushButton_2_clicked();

public:
    void setData(QString nomU,QString typeU);
    QString role,nom_u;
private:
    Ui::DialogInvite *ui;
    invite  inv;
    Notifications notifier;
    int mref;
    QByteArray data;
    Arduino A;
    int arduino_connected;

};

#endif // DIALOGINVITE_H
