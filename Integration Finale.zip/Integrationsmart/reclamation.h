#ifndef RECLAMATION_H
#define RECLAMATION_H
#include <QSqlQuery>
#include <QSqlQueryModel>

class reclamation
{
public:
    reclamation();
    reclamation(QString,QString,QString,QString,int);
    bool ajouter();
    bool modifier(int);
     QSqlQueryModel * afficher();
      bool supprimer(int);
      QSqlQueryModel *get_id_client();

      int Id_reclamation;
      QString Description,Id_client,Date,Type;
};

#endif // RECLAMATION_H
