#include "reclamation.h"

reclamation::reclamation()
{

}

reclamation::reclamation(QString s1 ,QString s2,QString s3 ,QString s4 ,int i ){
    Id_reclamation=i;
    Description=s4;
    Id_client=s2;
    Date=s3;
    Type=s1;
}


bool reclamation::ajouter(){

    QSqlQuery query;


    query.prepare("INSERT INTO reclamation (Id_reclamation, Description,Id_client,Date_re,Type) "
                        "VALUES (:Id_reclamation, :Description, :Id_client,:Date,:Type)");
    query.bindValue(":Id_reclamation", Id_reclamation);
    query.bindValue(":Description",Description); //remplir la valeur d'une maniere securisée
    query.bindValue(":Id_client", Id_client);
    query.bindValue(":Date", Date);
    query.bindValue(":Type", Type);

    return    query.exec();

}

bool reclamation::modifier(int selected){

    QSqlQuery query;


    query.prepare(" UPDATE reclamation SET Id_client= :Id_client ,Description= :Description ,Date_re= :Date,Type= :Type where Id_reclamation= :selected");
    query.bindValue(":selected", selected);
    query.bindValue(":Description",Description); //remplir la valeur d'une maniere securisée
    query.bindValue(":Id_client", Id_client);
    query.bindValue(":Date", Date);
    query.bindValue(":Type", Type);


    return    query.exec();

}

 QSqlQueryModel * reclamation::afficher(){

     QSqlQueryModel * modal=new QSqlQueryModel();
     modal->setQuery("SELECT * FROM reclamation");

     return modal;

 }
  bool reclamation::supprimer(int selected){

      QSqlQuery query;
      query.prepare("Delete from reclamation where Id_reclamation = :sel ");
      query.bindValue(":sel", selected);
      return    query.exec();


  }
  QSqlQueryModel * reclamation::get_id_client(){

      QSqlQueryModel * modal=new QSqlQueryModel();
      modal->setQuery("SELECT ID_Client FROM client");

      return modal;

  }
