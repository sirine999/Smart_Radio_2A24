#ifndef GERER_PROGRAMMES_H
#define GERER_PROGRAMMES_H
#include <QSqlError>
#include <QSqlQuery>
#include "gprogrammes.h"
#include <QString>
#include <QSqlQuery>
#include<QtDebug>
#include<QObject>
#include<QPrinter>
#include<QPainter>
#include<QtCharts>
#include<QChartView>
#include <QFile>
#include "smtp.h"
#include "arduino.h"
#include <QWidget>
#include <QDialog>




namespace Ui {
class gerer_programmes;
}

class gerer_programmes : public QDialog
{
    Q_OBJECT

public:
    explicit gerer_programmes(QWidget *parent = nullptr);
    ~gerer_programmes();
    QString role,nom_u;

private slots:
    void update_label();   // slot permettant la mise à jour du label état de la lampe 1,
    // ce slot est lancé à chaque réception d'un message de Arduino


    void on_ajouter_clicked();

    void on_Supprimer_clicked();

    void on_Modifier_clicked();

    void on_TableauAffichage_activated(const QModelIndex &index);

    void on_Trier_clicked();

    int on_ImporterPDF_clicked();

    void on_Rechercher_clicked();

    void sendMail();

    void mailSent(QString);

    void browse();

    void on_HISTORIQUE_clicked();


    void on_Quitter_clicked();

    void on_Quitter_2_clicked();

    void on_Quitter_3_clicked();

    void on_Quitter_4_clicked();

    void on_pushButton_retour_clicked();

private:
    Ui::gerer_programmes *ui;
    GProgrammes Etmp;
    QStringList files;
    QByteArray data; // variable contenant les données reçues

    Arduino A; // objet temporaire
};

#endif // GERER_PROGRAMMES_H
