#include "reclamation_workspace.h"
#include "ui_reclamation_workspace.h"
#include "accueil.h"

reclamation_workspace::reclamation_workspace(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::reclamation_workspace)
{
    ui->setupUi(this);


        //fill combo boxes : client / emp / salle
        reclamation ev;
        ui->client->setModel(ev.get_id_client());

       //affichage contenu base
       show_table();
}

reclamation_workspace::~reclamation_workspace()
{
    delete ui;
}

//recuperation des donnees du formulaire
int reclamation_workspace::code() const{ //integer

    return ui->code->value();
}


QString reclamation_workspace::description() const { //text edit
    return ui->description->toPlainText();
}

QString reclamation_workspace::type() const { //combo box

    return ui->type->currentText();
}

QString reclamation_workspace::client() const { //combo box

    return ui->client->currentText();
}


QString reclamation_workspace::get_date() const { //date
    return ui->dateEdit->date().toString("dd.MM.yyyy");
}

//remplissage des champs du formulaire a partir de la base

void reclamation_workspace::fill_form(int selected ) {
    QSqlQuery query;
    query.prepare("select * from reclamation where Id_reclamation= :code");
    query.bindValue(":code", selected);
    query.exec();
    while(query.next()){
        ui->dateEdit->setDate(QDate::fromString(query.value(3).toString(),"dd.MM.yyyy"));//date // bech na3mel date men string QDate::fromString(string,format)
 ui->description->setText(query.value(4).toString());//text edit
   ui->type->setCurrentText(query.value(1).toString()); //combobox
   ui->client->setCurrentText(query.value(2).toString()); //combobox
       ui->code->setValue(selected);// integer
    }
}

// +++++++++++++++++++++ CRUD ++++++++++++++++++++++++++++++++++++++++++

//affichage + metier tri
void reclamation_workspace::show_table(){
//creation model (masque du tableau) : permet recherche et tri
    proxy = new QSortFilterProxyModel();

 //definir la source (tableau original)
    proxy->setSourceModel(tmp.afficher()); //tmp de type event

 //pour la recherche
    proxy->setFilterCaseSensitivity(Qt::CaseInsensitive); // S=s (pas de difference entre majiscule et miniscule)
    proxy->setFilterKeyColumn(-1); // chercher dans tout le tableau (-1) ou donner le numero de la colone
   //remplissage tableau avec le masque
    ui->tableau->setModel(proxy);

}

//recuperer l'entier (integer) on l'appelle selected
void reclamation_workspace::on_tableau_doubleClicked(const QModelIndex &index)
{
     selected=ui->tableau->model()->data(index).toInt();
     fill_form(selected);
}

void reclamation_workspace::on_comboBox_currentIndexChanged(int index)
{
    search_col = ui->comboBox->currentIndex()-1;
    proxy->setFilterKeyColumn(search_col);
}

//ajouter
void reclamation_workspace::on_add_clicked()
{
    //recuperation des donnees
      int r=code();
      QString s4=description();
      QString s1=type();
      QString s3=get_date();
      QString s2=client();


      //mofication
      reclamation mc(s1,s2,s3,s4,r);
      mc.ajouter();



    //refresh du tableau (affichage)
     show_table();

     //clear form
     ui->code->clear();
     ui->description->clear();
     ui->type->setCurrentIndex(0);
     ui->client->setCurrentIndex(0);


}

//modifier
void reclamation_workspace::on_update_clicked()
{
  //recuperation des donnees
    QString s4=description();
    QString s1=type();
    QString s3=get_date();
    QString s2=client();

    //mofication
    reclamation mc(s1,s2,s3,s4,selected);
    mc.modifier(selected);



  //refresh du tableau (affichage)
   show_table();

   //clear form
   ui->code->clear();
   ui->description->clear();
   ui->type->setCurrentIndex(0);
   ui->client->setCurrentIndex(0);
}

//delete
void reclamation_workspace::on_delete_2_clicked()
{
    reclamation mc;
  mc.supprimer(selected);

 //refresh du tableau (affichage)
   show_table();


}

// +++++++++++++++++++++ METIER ++++++++++++++++++++++++++++++++++++++++++

//recherche dynamique
void reclamation_workspace::on_recherche_textChanged(const QString &arg1)
{
proxy->setFilterFixedString(arg1);
}


//stat
void reclamation_workspace::on_pushButton_clicked()
{
    s = new stat_combo(); //constructeur par defaut creation instance

  s->setWindowTitle("statistique par Type");
  s->choix_pie(); //la fonction elitesna3 pie
  s->show();
}

//pdf
void reclamation_workspace::on_pushButton_2_clicked()
{

    QString strStream;
                QTextStream out(&strStream);
                const int rowCount = ui->tableau->model()->rowCount();
                const int columnCount =ui->tableau->model()->columnCount();


                out <<  "<html>\n"
                        "<head>\n"
                        "<meta Content=\"Text/html; charset=Windows-1251\">\n"
                        <<  QString("<title>%1</title>\n").arg("eleve")
                        <<  "</head>\n"
                        "<body bgcolor=#CFC4E1 link=#5000A0>\n"
                            "<h1>Liste des reclamations</h1>"

                            "<table border=1 cellspacing=0 cellpadding=2>\n";

                // headers
                    out << "<thead><tr bgcolor=#f0f0f0>";
                    for (int column = 0; column < columnCount; column++)
                        if (!ui->tableau->isColumnHidden(column))
                            out << QString("<th>%1</th>").arg(ui->tableau->model()->headerData(column, Qt::Horizontal).toString());
                    out << "</tr></thead>\n";
                    // data table
                       for (int row = 0; row < rowCount; row++) {
                           out << "<tr>";
                           for (int column = 0; column < columnCount; column++) {
                               if (!ui->tableau->isColumnHidden(column)) {
                                   QString data = ui->tableau->model()->data(ui->tableau->model()->index(row, column)).toString().simplified();
                                   out << QString("<td bkcolor=0>%1</td>").arg((!data.isEmpty()) ? data : QString("&nbsp;"));
                               }
                           }
                           out << "</tr>\n";
                       }
                       out <<  "</table>\n"
                           "</body>\n"
                           "</html>\n";



        QTextDocument *document = new QTextDocument();
        document->setHtml(strStream);


        //QTextDocument document;
        //document.setHtml(html);
        QPrinter printer(QPrinter::PrinterResolution);
        printer.setOutputFormat(QPrinter::PdfFormat);
        printer.setOutputFileName("liste_reclamations.pdf");
        document->print(&printer);


}

//camera and take image
void reclamation_workspace::on_camera_clicked()
{
    c= new camera();
    c->show();
}

//sending SMS
void reclamation_workspace::on_pushButton_3_clicked()
{
    Smtp* smtp = new Smtp("baya.chaaben@esprit.tn","211JFT9870", "smtp.gmail.com");
    connect(smtp, SIGNAL(status(QString)), this, SLOT(mailSent(QString)));

        smtp->sendMail("baya.chaaben@esprit.tn", "baya.chaaben@esprit.tn", ui->sms->text(),"sms body from mail");

        ui->sms->clear();
}

void reclamation_workspace::on_pushButton_4_clicked()
{
    close();
    accueil *ac=new accueil();
    ac->show();
}
