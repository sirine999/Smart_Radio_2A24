#ifndef RECLAMATION_WORKSPACE_H
#define RECLAMATION_WORKSPACE_H

#include <QMainWindow>
#include <QSortFilterProxyModel>
#include <QTextTableFormat>
#include <QStandardItemModel>
#include <QPrinter>
#include <QTextStream>
#include <QFile>
#include <QDataStream>

#include "reclamation.h"
#include "stat_combo.h"
#include "camera.h"
#include "smtp.h"


namespace Ui {
class reclamation_workspace;
}

class reclamation_workspace : public QMainWindow
{
    Q_OBJECT

public:
    explicit reclamation_workspace(QWidget *parent = nullptr);
    ~reclamation_workspace();
    reclamation tmp;
       QSortFilterProxyModel *proxy;

       void show_table();

       QString get_date() const ;
       QString type() const;
       QString client() const ;
       QString description() const ;
       int code() const;

       void fill_form(int);

private slots:
    void on_add_clicked();

    void on_update_clicked();

    void on_delete_2_clicked();

    void on_tableau_doubleClicked(const QModelIndex &index);

    void on_recherche_textChanged(const QString &arg1);


    void on_pushButton_clicked();

    void on_comboBox_currentIndexChanged(int index);


    void on_pushButton_2_clicked();

    void on_camera_clicked();

    void on_pushButton_3_clicked();


    void on_pushButton_4_clicked();

private:
    Ui::reclamation_workspace *ui;
    int selected=0,search_col=-1;
        stat_combo *s;
        QWidget* widget;
        camera *c;
};

#endif // RECLAMATION_WORKSPACE_H
