#include "mainwindow.h"
#include <QApplication>
#include "employe.h"
#include "mainwindow.h"
#include <QMessageBox>
#include <QDebug>
#include "connection.h"
#include "employes.h"
#include <QFile>
#include <QInputDialog>
#include "gerer_employes.h"
#include "accueil.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Connection c;
    bool test=c.createconnection();
    MainWindow w;

    if(test)
    {

        QMessageBox::information(nullptr, QObject::tr("La base de données est ouverte"),
                    QObject::tr("connecté avec succès.\n"
                                "Cliquez sur OK pour Quitter."), QMessageBox::Ok);
        accueil c;
        w.show();

    }
    else
        QMessageBox::critical(nullptr, QObject::tr("La base de données n'est pas ouverte"),
                    QObject::tr("la connexion a échoué.\n"
                                "Cliquez sur Annuler pour quitter."), QMessageBox::Cancel);
//------------------------------------------------------------------------------------|
 accueil ch;
ch.show();

    return a.exec();
}
