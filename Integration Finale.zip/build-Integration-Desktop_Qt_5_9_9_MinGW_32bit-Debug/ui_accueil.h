/********************************************************************************
** Form generated from reading UI file 'accueil.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCUEIL_H
#define UI_ACCUEIL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_accueil
{
public:
    QGroupBox *groupBox;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_employes;
    QPushButton *pushButton_invites;
    QPushButton *pushButton_programmes;
    QPushButton *pushButton_publicites;
    QPushButton *pushButton_reclamations;
    QPushButton *pushButton_materiaux;
    QLabel *label;
    QLabel *label_2;

    void setupUi(QDialog *accueil)
    {
        if (accueil->objectName().isEmpty())
            accueil->setObjectName(QStringLiteral("accueil"));
        accueil->resize(1400, 750);
        accueil->setStyleSheet(QStringLiteral("background-image: url(:/new/picture/bjk.jpg);"));
        groupBox = new QGroupBox(accueil);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(0, 30, 951, 691));
        groupBox->setStyleSheet(QStringLiteral("font: 12pt \"Berlin Sans FB\";"));
        layoutWidget = new QWidget(groupBox);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(100, 90, 215, 501));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_employes = new QPushButton(layoutWidget);
        pushButton_employes->setObjectName(QStringLiteral("pushButton_employes"));
        pushButton_employes->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(pushButton_employes);

        pushButton_invites = new QPushButton(layoutWidget);
        pushButton_invites->setObjectName(QStringLiteral("pushButton_invites"));
        pushButton_invites->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(pushButton_invites);

        pushButton_programmes = new QPushButton(layoutWidget);
        pushButton_programmes->setObjectName(QStringLiteral("pushButton_programmes"));
        pushButton_programmes->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(pushButton_programmes);

        pushButton_publicites = new QPushButton(layoutWidget);
        pushButton_publicites->setObjectName(QStringLiteral("pushButton_publicites"));
        pushButton_publicites->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(pushButton_publicites);

        pushButton_reclamations = new QPushButton(layoutWidget);
        pushButton_reclamations->setObjectName(QStringLiteral("pushButton_reclamations"));
        pushButton_reclamations->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(pushButton_reclamations);

        pushButton_materiaux = new QPushButton(layoutWidget);
        pushButton_materiaux->setObjectName(QStringLiteral("pushButton_materiaux"));
        pushButton_materiaux->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(pushButton_materiaux);

        label = new QLabel(accueil);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(930, 140, 1201, 821));
        label->setStyleSheet(QStringLiteral("background-image: url(:/office-modular-workspace.jpg);"));
        label_2 = new QLabel(accueil);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(1360, 300, 381, 31));
        label_2->setStyleSheet(QStringLiteral("font: 12pt \"MS Shell Dlg 2\";"));
        label_2->setAlignment(Qt::AlignCenter);

        retranslateUi(accueil);

        QMetaObject::connectSlotsByName(accueil);
    } // setupUi

    void retranslateUi(QDialog *accueil)
    {
        accueil->setWindowTitle(QApplication::translate("accueil", "Dialog", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("accueil", "Welcome :", Q_NULLPTR));
        pushButton_employes->setText(QApplication::translate("accueil", "Gestion des Employ\303\251s", Q_NULLPTR));
        pushButton_invites->setText(QApplication::translate("accueil", "Gestion des invit\303\251s", Q_NULLPTR));
        pushButton_programmes->setText(QApplication::translate("accueil", "Gestion des programmes", Q_NULLPTR));
        pushButton_publicites->setText(QApplication::translate("accueil", "Gestion des Publicit\303\251s", Q_NULLPTR));
        pushButton_reclamations->setText(QApplication::translate("accueil", "Gestion des r\303\251clamations", Q_NULLPTR));
        pushButton_materiaux->setText(QApplication::translate("accueil", "Gestion des Mat\303\251riaux", Q_NULLPTR));
        label->setText(QString());
        label_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class accueil: public Ui_accueil {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCUEIL_H
