/********************************************************************************
** Form generated from reading UI file 'gerer_materiel.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GERER_MATERIEL_H
#define UI_GERER_MATERIEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateTimeEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gerer_materiel
{
public:
    QGroupBox *groupBox;
    QGroupBox *groupBox_11;
    QLabel *label_12;
    QGroupBox *groupBox_12;
    QLabel *label_13;
    QTabWidget *tabWidget;
    QWidget *ajouter_un_materiel;
    QGroupBox *groupBox_2;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *le_id;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_6;
    QLineEdit *le_marque;
    QDateTimeEdit *le_heu_date;
    QPushButton *pb_ajouter;
    QLabel *label_10;
    QLineEdit *le_nom;
    QPushButton *pb_modif;
    QPushButton *pb_supprimer;
    QLineEdit *le_prix;
    QTableView *tab_materiel;
    QComboBox *comboBox_tri;
    QPushButton *pushButton_trie;
    QLineEdit *le_rech;
    QPushButton *pushButton_Recherche;
    QPushButton *pdf;
    QLineEdit *le_departement;
    QComboBox *comboBox_chercher;
    QProgressBar *progressBar;
    QPushButton *pb_qr;
    QPushButton *inserer_image;
    QPushButton *pb_pdf1;
    QPushButton *calcul;
    QWidget *tab;
    QGroupBox *groupBox_6;
    QFrame *horizontalFrame;
    QHBoxLayout *horizontalLayout;
    QWidget *tab_3;
    QLabel *qrcode;
    QWidget *tab_4;
    QLabel *label_image;
    QPushButton *on;
    QLabel *image;
    QPushButton *pushButton_retour;

    void setupUi(QDialog *gerer_materiel)
    {
        if (gerer_materiel->objectName().isEmpty())
            gerer_materiel->setObjectName(QStringLiteral("gerer_materiel"));
        gerer_materiel->resize(1400, 750);
        gerer_materiel->setStyleSheet(QStringLiteral("background-image: url(:/new/picture/backgp.jpg);"));
        groupBox = new QGroupBox(gerer_materiel);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(90, 20, 1181, 701));
        groupBox->setStyleSheet(QStringLiteral("background-color: rgb(170, 170, 255);"));
        groupBox_11 = new QGroupBox(groupBox);
        groupBox_11->setObjectName(QStringLiteral("groupBox_11"));
        groupBox_11->setGeometry(QRect(300, 30, 391, 41));
        groupBox_11->setStyleSheet(QStringLiteral("background-color: rgb(255, 222, 227);"));
        label_12 = new QLabel(groupBox_11);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(110, 0, 191, 41));
        QFont font;
        font.setFamily(QStringLiteral("Berlin Sans FB"));
        font.setPointSize(12);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        label_12->setFont(font);
        label_12->setStyleSheet(QStringLiteral("font: 12pt \"Berlin Sans FB\";"));
        groupBox_12 = new QGroupBox(groupBox_11);
        groupBox_12->setObjectName(QStringLiteral("groupBox_12"));
        groupBox_12->setGeometry(QRect(10, 10, 391, 41));
        groupBox_12->setStyleSheet(QStringLiteral("background-color: rgb(255, 222, 227);"));
        label_13 = new QLabel(groupBox_12);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(110, 0, 191, 41));
        label_13->setFont(font);
        label_13->setStyleSheet(QStringLiteral("font: 12pt \"Berlin Sans FB\";"));
        tabWidget = new QTabWidget(groupBox);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(10, 100, 1161, 551));
        tabWidget->setStyleSheet(QLatin1String("font: 12pt \"Berlin Sans FB\";\n"
""));
        ajouter_un_materiel = new QWidget();
        ajouter_un_materiel->setObjectName(QStringLiteral("ajouter_un_materiel"));
        groupBox_2 = new QGroupBox(ajouter_un_materiel);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 10, 1131, 501));
        groupBox_2->setFont(font);
        groupBox_2->setStyleSheet(QLatin1String("background-color: rgb(255, 222, 227);\n"
"font: 12pt \"Berlin Sans FB\";\n"
""));
        label = new QLabel(groupBox_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 70, 161, 41));
        label->setFont(font);
        label->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_2 = new QLabel(groupBox_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 40, 101, 21));
        label_2->setFont(font);
        label_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_id = new QLineEdit(groupBox_2);
        le_id->setObjectName(QStringLiteral("le_id"));
        le_id->setGeometry(QRect(120, 40, 131, 21));
        le_id->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_id->setEchoMode(QLineEdit::Password);
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 120, 171, 21));
        label_3->setFont(font);
        label_3->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(290, 40, 121, 21));
        label_4->setFont(font);
        label_4->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(310, 80, 121, 31));
        label_6->setFont(font);
        label_6->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_marque = new QLineEdit(groupBox_2);
        le_marque->setObjectName(QStringLiteral("le_marque"));
        le_marque->setGeometry(QRect(190, 120, 131, 21));
        le_marque->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_heu_date = new QDateTimeEdit(groupBox_2);
        le_heu_date->setObjectName(QStringLiteral("le_heu_date"));
        le_heu_date->setGeometry(QRect(440, 80, 211, 22));
        le_heu_date->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        pb_ajouter = new QPushButton(groupBox_2);
        pb_ajouter->setObjectName(QStringLiteral("pb_ajouter"));
        pb_ajouter->setGeometry(QRect(670, 30, 111, 31));
        pb_ajouter->setFont(font);
        pb_ajouter->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_10 = new QLabel(groupBox_2);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(340, 120, 101, 21));
        label_10->setFont(font);
        label_10->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_nom = new QLineEdit(groupBox_2);
        le_nom->setObjectName(QStringLiteral("le_nom"));
        le_nom->setGeometry(QRect(160, 80, 131, 21));
        le_nom->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pb_modif = new QPushButton(groupBox_2);
        pb_modif->setObjectName(QStringLiteral("pb_modif"));
        pb_modif->setGeometry(QRect(670, 70, 111, 31));
        pb_modif->setFont(font);
        pb_modif->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pb_supprimer = new QPushButton(groupBox_2);
        pb_supprimer->setObjectName(QStringLiteral("pb_supprimer"));
        pb_supprimer->setGeometry(QRect(670, 110, 111, 31));
        pb_supprimer->setFont(font);
        pb_supprimer->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_prix = new QLineEdit(groupBox_2);
        le_prix->setObjectName(QStringLiteral("le_prix"));
        le_prix->setGeometry(QRect(460, 120, 131, 22));
        le_prix->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        tab_materiel = new QTableView(groupBox_2);
        tab_materiel->setObjectName(QStringLiteral("tab_materiel"));
        tab_materiel->setGeometry(QRect(10, 160, 971, 331));
        tab_materiel->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        comboBox_tri = new QComboBox(groupBox_2);
        comboBox_tri->setObjectName(QStringLiteral("comboBox_tri"));
        comboBox_tri->setGeometry(QRect(1000, 260, 101, 31));
        pushButton_trie = new QPushButton(groupBox_2);
        pushButton_trie->setObjectName(QStringLiteral("pushButton_trie"));
        pushButton_trie->setGeometry(QRect(1000, 300, 101, 31));
        pushButton_trie->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_rech = new QLineEdit(groupBox_2);
        le_rech->setObjectName(QStringLiteral("le_rech"));
        le_rech->setGeometry(QRect(1000, 410, 111, 31));
        le_rech->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pushButton_Recherche = new QPushButton(groupBox_2);
        pushButton_Recherche->setObjectName(QStringLiteral("pushButton_Recherche"));
        pushButton_Recherche->setGeometry(QRect(1000, 450, 111, 31));
        pushButton_Recherche->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pdf = new QPushButton(groupBox_2);
        pdf->setObjectName(QStringLiteral("pdf"));
        pdf->setGeometry(QRect(1000, 210, 111, 31));
        pdf->setFont(font);
        pdf->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_departement = new QLineEdit(groupBox_2);
        le_departement->setObjectName(QStringLiteral("le_departement"));
        le_departement->setGeometry(QRect(410, 40, 131, 22));
        le_departement->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        comboBox_chercher = new QComboBox(groupBox_2);
        comboBox_chercher->setObjectName(QStringLiteral("comboBox_chercher"));
        comboBox_chercher->setGeometry(QRect(1000, 370, 101, 31));
        progressBar = new QProgressBar(groupBox_2);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setGeometry(QRect(910, 110, 118, 23));
        progressBar->setValue(24);
        pb_qr = new QPushButton(groupBox_2);
        pb_qr->setObjectName(QStringLiteral("pb_qr"));
        pb_qr->setGeometry(QRect(810, 110, 93, 28));
        pb_qr->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        inserer_image = new QPushButton(groupBox_2);
        inserer_image->setObjectName(QStringLiteral("inserer_image"));
        inserer_image->setGeometry(QRect(810, 70, 141, 31));
        inserer_image->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pb_pdf1 = new QPushButton(groupBox_2);
        pb_pdf1->setObjectName(QStringLiteral("pb_pdf1"));
        pb_pdf1->setGeometry(QRect(810, 30, 141, 28));
        pb_pdf1->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        calcul = new QPushButton(groupBox_2);
        calcul->setObjectName(QStringLiteral("calcul"));
        calcul->setGeometry(QRect(1000, 160, 111, 31));
        calcul->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        tabWidget->addTab(ajouter_un_materiel, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        groupBox_6 = new QGroupBox(tab);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        groupBox_6->setGeometry(QRect(0, 10, 1071, 501));
        QFont font1;
        font1.setFamily(QStringLiteral("Berlin Sans FB"));
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        groupBox_6->setFont(font1);
        groupBox_6->setStyleSheet(QLatin1String("background-color: rgb(255, 222, 227);\n"
"font: 10pt \"Berlin Sans FB\";"));
        horizontalFrame = new QFrame(groupBox_6);
        horizontalFrame->setObjectName(QStringLiteral("horizontalFrame"));
        horizontalFrame->setGeometry(QRect(20, 30, 1021, 441));
        horizontalLayout = new QHBoxLayout(horizontalFrame);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        qrcode = new QLabel(tab_3);
        qrcode->setObjectName(QStringLiteral("qrcode"));
        qrcode->setGeometry(QRect(90, 20, 791, 471));
        qrcode->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        label_image = new QLabel(tab_4);
        label_image->setObjectName(QStringLiteral("label_image"));
        label_image->setGeometry(QRect(20, 10, 701, 501));
        label_image->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        on = new QPushButton(tab_4);
        on->setObjectName(QStringLiteral("on"));
        on->setGeometry(QRect(820, 150, 201, 81));
        on->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        tabWidget->addTab(tab_4, QString());
        image = new QLabel(groupBox);
        image->setObjectName(QStringLiteral("image"));
        image->setGeometry(QRect(930, 10, 151, 91));
        image->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        pushButton_retour = new QPushButton(groupBox);
        pushButton_retour->setObjectName(QStringLiteral("pushButton_retour"));
        pushButton_retour->setGeometry(QRect(1060, 660, 111, 31));
        pushButton_retour->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));

        retranslateUi(gerer_materiel);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(gerer_materiel);
    } // setupUi

    void retranslateUi(QDialog *gerer_materiel)
    {
        gerer_materiel->setWindowTitle(QApplication::translate("gerer_materiel", "Dialog", Q_NULLPTR));
        groupBox->setTitle(QString());
        groupBox_11->setTitle(QString());
        label_12->setText(QApplication::translate("gerer_materiel", "Gestion des mat\303\251riaux", Q_NULLPTR));
        groupBox_12->setTitle(QString());
        label_13->setText(QApplication::translate("gerer_materiel", "Gestion des mat\303\251riaux", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("gerer_materiel", "ajouter un mat\303\251riel", Q_NULLPTR));
        label->setText(QApplication::translate("gerer_materiel", "nom du mat\303\251riel", Q_NULLPTR));
        label_2->setText(QApplication::translate("gerer_materiel", "Id du mat\303\251riel", Q_NULLPTR));
        label_3->setText(QApplication::translate("gerer_materiel", "Marque du mat\303\251riel", Q_NULLPTR));
        label_4->setText(QApplication::translate("gerer_materiel", "D\303\251partement", Q_NULLPTR));
        label_6->setText(QApplication::translate("gerer_materiel", "Heure et Date", Q_NULLPTR));
        pb_ajouter->setText(QApplication::translate("gerer_materiel", "Ajouter", Q_NULLPTR));
        label_10->setText(QApplication::translate("gerer_materiel", "Prix par dt", Q_NULLPTR));
        pb_modif->setText(QApplication::translate("gerer_materiel", "Modifier", Q_NULLPTR));
        pb_supprimer->setText(QApplication::translate("gerer_materiel", "Supprimer", Q_NULLPTR));
        comboBox_tri->clear();
        comboBox_tri->insertItems(0, QStringList()
         << QApplication::translate("gerer_materiel", "nom", Q_NULLPTR)
         << QApplication::translate("gerer_materiel", "id", Q_NULLPTR)
         << QApplication::translate("gerer_materiel", "prix", Q_NULLPTR)
        );
        pushButton_trie->setText(QApplication::translate("gerer_materiel", "trier", Q_NULLPTR));
        pushButton_Recherche->setText(QApplication::translate("gerer_materiel", "chercher", Q_NULLPTR));
        pdf->setText(QApplication::translate("gerer_materiel", "PDF ", Q_NULLPTR));
        comboBox_chercher->clear();
        comboBox_chercher->insertItems(0, QStringList()
         << QApplication::translate("gerer_materiel", "nom", Q_NULLPTR)
         << QApplication::translate("gerer_materiel", "id", Q_NULLPTR)
         << QApplication::translate("gerer_materiel", "marque", Q_NULLPTR)
         << QApplication::translate("gerer_materiel", "departement", Q_NULLPTR)
        );
        pb_qr->setText(QApplication::translate("gerer_materiel", "QR", Q_NULLPTR));
        inserer_image->setText(QApplication::translate("gerer_materiel", "insertion image", Q_NULLPTR));
        pb_pdf1->setText(QApplication::translate("gerer_materiel", "fichier PDF", Q_NULLPTR));
        calcul->setText(QApplication::translate("gerer_materiel", "calculatrice", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(ajouter_un_materiel), QApplication::translate("gerer_materiel", "ajouter_un materiel", Q_NULLPTR));
        groupBox_6->setTitle(QApplication::translate("gerer_materiel", "statistiques", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("gerer_materiel", "statistiques", Q_NULLPTR));
        qrcode->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("gerer_materiel", "QrCode", Q_NULLPTR));
        label_image->setText(QString());
        on->setText(QApplication::translate("gerer_materiel", "arduino", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("gerer_materiel", "image", Q_NULLPTR));
        image->setText(QString());
        pushButton_retour->setText(QApplication::translate("gerer_materiel", "Retour", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class gerer_materiel: public Ui_gerer_materiel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GERER_MATERIEL_H
