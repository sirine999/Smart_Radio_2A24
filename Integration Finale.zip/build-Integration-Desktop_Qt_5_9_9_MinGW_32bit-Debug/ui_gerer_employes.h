/********************************************************************************
** Form generated from reading UI file 'gerer_employes.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GERER_EMPLOYES_H
#define UI_GERER_EMPLOYES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_gerer_employes
{
public:
    QTabWidget *tabWidget_2;
    QWidget *modif_cl;
    QGroupBox *ajout_cl;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_11;
    QPushButton *pb_ajout_em;
    QLabel *label_5;
    QLineEdit *le_prenom;
    QLineEdit *le_id;
    QLineEdit *le_salaire;
    QLabel *label_3;
    QLabel *label_2;
    QLineEdit *le_nom;
    QLineEdit *le_adresse;
    QLineEdit *le_mail;
    QLabel *label_4;
    QLabel *label_6;
    QLabel *label_8;
    QTableView *tab_emp;
    QComboBox *cb_genre;
    QLabel *label_7;
    QLabel *label_14;
    QLabel *label_34;
    QComboBox *cb_tri;
    QComboBox *cb_rech_emp;
    QLineEdit *le_rech;
    QPushButton *search_pb;
    QPushButton *pushButton;
    QComboBox *cb_pdf;
    QLabel *label_35;
    QPushButton *pb_stat;
    QPushButton *pushButton_2;
    QWidget *tab_4;
    QGroupBox *groupBox_3;
    QLabel *label_9;
    QLabel *label_10;
    QPushButton *pushButton_5;
    QPushButton *pb_modif_emp;
    QComboBox *cb_id_modif;
    QLineEdit *le_nom_modif;
    QLineEdit *le_salaire_modif;
    QLineEdit *le_prenom_modif;
    QLabel *label_13;
    QLineEdit *le_adresse_modif;
    QLabel *label_15;
    QLabel *label_18;
    QLabel *label_11;
    QLabel *label_12;
    QLineEdit *le_mail_modif;
    QLabel *label_19;
    QComboBox *cb_genre_modif;
    QWidget *supp_cl;
    QGroupBox *groupBox_5;
    QLabel *label_16;
    QLabel *label_17;
    QPushButton *pb_supprimer_employe;
    QPushButton *pushButton_10;
    QComboBox *cb_id_supp;
    QLabel *idArd;
    QLabel *nomArd;
    QLabel *RFIDard;
    QLabel *label;
    QLabel *label_20;
    QLabel *label_21;
    QLabel *ER;

    void setupUi(QDialog *gerer_employes)
    {
        if (gerer_employes->objectName().isEmpty())
            gerer_employes->setObjectName(QStringLiteral("gerer_employes"));
        gerer_employes->resize(948, 816);
        tabWidget_2 = new QTabWidget(gerer_employes);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setGeometry(QRect(0, 0, 831, 711));
        tabWidget_2->setStyleSheet(QStringLiteral("background-color:rgb(226, 226, 226);"));
        modif_cl = new QWidget();
        modif_cl->setObjectName(QStringLiteral("modif_cl"));
        ajout_cl = new QGroupBox(modif_cl);
        ajout_cl->setObjectName(QStringLiteral("ajout_cl"));
        ajout_cl->setGeometry(QRect(10, 0, 771, 731));
        ajout_cl->setStyleSheet(QStringLiteral("background-color:rgb(170, 170,255);"));
        lineEdit_3 = new QLineEdit(ajout_cl);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(290, 190, 161, 41));
        QFont font;
        font.setFamily(QStringLiteral("calibri"));
        font.setBold(true);
        font.setUnderline(false);
        font.setWeight(75);
        font.setStrikeOut(false);
        lineEdit_3->setFont(font);
        lineEdit_3->setStyleSheet(QLatin1String("background-color: black	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        lineEdit_3->setReadOnly(true);
        pushButton_11 = new QPushButton(ajout_cl);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(360, 630, 101, 41));
        QFont font1;
        font1.setFamily(QStringLiteral("calibri"));
        font1.setBold(true);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(75);
        font1.setStrikeOut(false);
        font1.setKerning(true);
        pushButton_11->setFont(font1);
        pushButton_11->setAutoFillBackground(false);
        pushButton_11->setStyleSheet(QLatin1String("background-color: #8B0000	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        pb_ajout_em = new QPushButton(ajout_cl);
        pb_ajout_em->setObjectName(QStringLiteral("pb_ajout_em"));
        pb_ajout_em->setGeometry(QRect(660, 80, 101, 41));
        pb_ajout_em->setFont(font1);
        pb_ajout_em->setAutoFillBackground(false);
        pb_ajout_em->setStyleSheet(QLatin1String("background-color: black	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        label_5 = new QLabel(ajout_cl);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(260, 21, 61, 21));
        QFont font2;
        font2.setPointSize(8);
        font2.setBold(true);
        font2.setItalic(false);
        font2.setWeight(75);
        label_5->setFont(font2);
        le_prenom = new QLineEdit(ajout_cl);
        le_prenom->setObjectName(QStringLiteral("le_prenom"));
        le_prenom->setGeometry(QRect(110, 121, 113, 41));
        le_prenom->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_prenom->setReadOnly(false);
        le_id = new QLineEdit(ajout_cl);
        le_id->setObjectName(QStringLiteral("le_id"));
        le_id->setGeometry(QRect(110, 21, 113, 41));
        le_id->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_id->setReadOnly(false);
        le_salaire = new QLineEdit(ajout_cl);
        le_salaire->setObjectName(QStringLiteral("le_salaire"));
        le_salaire->setGeometry(QRect(360, 120, 113, 41));
        le_salaire->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_salaire->setReadOnly(false);
        label_3 = new QLabel(ajout_cl);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(260, 121, 101, 20));
        label_3->setFont(font2);
        label_2 = new QLabel(ajout_cl);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 31, 71, 20));
        label_2->setFont(font2);
        le_nom = new QLineEdit(ajout_cl);
        le_nom->setObjectName(QStringLiteral("le_nom"));
        le_nom->setGeometry(QRect(110, 70, 113, 41));
        le_nom->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"  font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_nom->setReadOnly(false);
        le_adresse = new QLineEdit(ajout_cl);
        le_adresse->setObjectName(QStringLiteral("le_adresse"));
        le_adresse->setGeometry(QRect(360, 11, 113, 41));
        le_adresse->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_adresse->setReadOnly(false);
        le_mail = new QLineEdit(ajout_cl);
        le_mail->setObjectName(QStringLiteral("le_mail"));
        le_mail->setGeometry(QRect(360, 61, 113, 41));
        le_mail->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_mail->setReadOnly(false);
        label_4 = new QLabel(ajout_cl);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(260, 71, 47, 21));
        label_4->setFont(font2);
        label_6 = new QLabel(ajout_cl);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(20, 81, 81, 20));
        label_6->setFont(font2);
        label_8 = new QLabel(ajout_cl);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(20, 131, 47, 21));
        label_8->setFont(font2);
        tab_emp = new QTableView(ajout_cl);
        tab_emp->setObjectName(QStringLiteral("tab_emp"));
        tab_emp->setGeometry(QRect(40, 240, 701, 191));
        tab_emp->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"border-radius:16px"));
        cb_genre = new QComboBox(ajout_cl);
        cb_genre->setObjectName(QStringLiteral("cb_genre"));
        cb_genre->setGeometry(QRect(640, 10, 131, 51));
        cb_genre->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        label_7 = new QLabel(ajout_cl);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(540, 30, 61, 21));
        label_7->setFont(font2);
        label_14 = new QLabel(ajout_cl);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(30, 450, 91, 41));
        QFont font3;
        font3.setPointSize(8);
        font3.setBold(true);
        font3.setWeight(75);
        label_14->setFont(font3);
        label_34 = new QLabel(ajout_cl);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setGeometry(QRect(300, 450, 111, 41));
        QFont font4;
        font4.setPointSize(10);
        font4.setBold(true);
        font4.setWeight(75);
        label_34->setFont(font4);
        cb_tri = new QComboBox(ajout_cl);
        cb_tri->setObjectName(QStringLiteral("cb_tri"));
        cb_tri->setGeometry(QRect(380, 450, 121, 41));
        cb_tri->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        cb_rech_emp = new QComboBox(ajout_cl);
        cb_rech_emp->setObjectName(QStringLiteral("cb_rech_emp"));
        cb_rech_emp->setGeometry(QRect(130, 450, 101, 41));
        cb_rech_emp->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_rech = new QLineEdit(ajout_cl);
        le_rech->setObjectName(QStringLiteral("le_rech"));
        le_rech->setGeometry(QRect(20, 500, 113, 41));
        le_rech->setStyleSheet(QLatin1String("background-color:white;\n"
"border-radius:16px"));
        search_pb = new QPushButton(ajout_cl);
        search_pb->setObjectName(QStringLiteral("search_pb"));
        search_pb->setGeometry(QRect(150, 500, 81, 41));
        search_pb->setStyleSheet(QLatin1String("background-color: black	;\n"
"  border: none;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"font-family:calibri;\n"
"  display: inline-block;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        pushButton = new QPushButton(ajout_cl);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(610, 510, 111, 41));
        pushButton->setStyleSheet(QLatin1String("background-color: black	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        cb_pdf = new QComboBox(ajout_cl);
        cb_pdf->setObjectName(QStringLiteral("cb_pdf"));
        cb_pdf->setGeometry(QRect(610, 450, 121, 51));
        cb_pdf->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        label_35 = new QLabel(ajout_cl);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(530, 460, 61, 41));
        label_35->setFont(font4);
        pb_stat = new QPushButton(ajout_cl);
        pb_stat->setObjectName(QStringLiteral("pb_stat"));
        pb_stat->setGeometry(QRect(610, 180, 111, 41));
        pb_stat->setStyleSheet(QLatin1String("background-color: black	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        pushButton_2 = new QPushButton(ajout_cl);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(352, 510, 81, 41));
        pushButton_2->setStyleSheet(QLatin1String("background-color: black	;\n"
"  border: none;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"font-family:calibri;\n"
"  display: inline-block;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        tabWidget_2->addTab(modif_cl, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        groupBox_3 = new QGroupBox(tab_4);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(0, 0, 781, 491));
        QFont font5;
        font5.setPointSize(11);
        font5.setBold(true);
        font5.setWeight(75);
        groupBox_3->setFont(font5);
        groupBox_3->setStyleSheet(QStringLiteral("background-color:rgb(170,170, 255);"));
        label_9 = new QLabel(groupBox_3);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(30, 40, 391, 31));
        QFont font6;
        font6.setPointSize(10);
        font6.setBold(true);
        font6.setItalic(false);
        font6.setWeight(75);
        label_9->setFont(font6);
        label_10 = new QLabel(groupBox_3);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(50, 110, 71, 20));
        label_10->setFont(font2);
        label_10->setStyleSheet(QStringLiteral("background-color:transparent;"));
        pushButton_5 = new QPushButton(groupBox_3);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(340, 410, 91, 41));
        pushButton_5->setFont(font1);
        pushButton_5->setAutoFillBackground(false);
        pushButton_5->setStyleSheet(QLatin1String("background-color: #8B0000	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        pb_modif_emp = new QPushButton(groupBox_3);
        pb_modif_emp->setObjectName(QStringLiteral("pb_modif_emp"));
        pb_modif_emp->setGeometry(QRect(660, 250, 91, 41));
        pb_modif_emp->setFont(font1);
        pb_modif_emp->setAutoFillBackground(false);
        pb_modif_emp->setStyleSheet(QLatin1String("background-color: black	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        cb_id_modif = new QComboBox(groupBox_3);
        cb_id_modif->setObjectName(QStringLiteral("cb_id_modif"));
        cb_id_modif->setGeometry(QRect(130, 101, 101, 41));
        cb_id_modif->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_nom_modif = new QLineEdit(groupBox_3);
        le_nom_modif->setObjectName(QStringLiteral("le_nom_modif"));
        le_nom_modif->setGeometry(QRect(220, 259, 113, 41));
        le_nom_modif->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_nom_modif->setReadOnly(false);
        le_salaire_modif = new QLineEdit(groupBox_3);
        le_salaire_modif->setObjectName(QStringLiteral("le_salaire_modif"));
        le_salaire_modif->setGeometry(QRect(470, 300, 113, 41));
        le_salaire_modif->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_salaire_modif->setReadOnly(false);
        le_prenom_modif = new QLineEdit(groupBox_3);
        le_prenom_modif->setObjectName(QStringLiteral("le_prenom_modif"));
        le_prenom_modif->setGeometry(QRect(220, 310, 113, 41));
        le_prenom_modif->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_prenom_modif->setReadOnly(false);
        label_13 = new QLabel(groupBox_3);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(130, 320, 47, 21));
        label_13->setFont(font2);
        le_adresse_modif = new QLineEdit(groupBox_3);
        le_adresse_modif->setObjectName(QStringLiteral("le_adresse_modif"));
        le_adresse_modif->setGeometry(QRect(470, 200, 113, 41));
        le_adresse_modif->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_adresse_modif->setReadOnly(false);
        label_15 = new QLabel(groupBox_3);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(370, 260, 47, 21));
        label_15->setFont(font2);
        label_18 = new QLabel(groupBox_3);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(370, 210, 61, 21));
        label_18->setFont(font2);
        label_11 = new QLabel(groupBox_3);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(130, 270, 81, 20));
        label_11->setFont(font2);
        label_12 = new QLabel(groupBox_3);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(370, 310, 101, 20));
        label_12->setFont(font2);
        le_mail_modif = new QLineEdit(groupBox_3);
        le_mail_modif->setObjectName(QStringLiteral("le_mail_modif"));
        le_mail_modif->setGeometry(QRect(470, 250, 113, 41));
        le_mail_modif->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        le_mail_modif->setReadOnly(false);
        label_19 = new QLabel(groupBox_3);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(130, 199, 61, 21));
        label_19->setFont(font2);
        cb_genre_modif = new QComboBox(groupBox_3);
        cb_genre_modif->setObjectName(QStringLiteral("cb_genre_modif"));
        cb_genre_modif->setGeometry(QRect(220, 189, 131, 51));
        cb_genre_modif->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        tabWidget_2->addTab(tab_4, QString());
        supp_cl = new QWidget();
        supp_cl->setObjectName(QStringLiteral("supp_cl"));
        groupBox_5 = new QGroupBox(supp_cl);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        groupBox_5->setGeometry(QRect(10, 0, 771, 501));
        groupBox_5->setFont(font5);
        groupBox_5->setStyleSheet(QStringLiteral("background-color:rgb(170,170, 250);"));
        label_16 = new QLabel(groupBox_5);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(40, 40, 491, 41));
        label_16->setFont(font6);
        label_17 = new QLabel(groupBox_5);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(60, 120, 71, 20));
        label_17->setFont(font2);
        label_17->setStyleSheet(QStringLiteral("background-color:transparent;"));
        pb_supprimer_employe = new QPushButton(groupBox_5);
        pb_supprimer_employe->setObjectName(QStringLiteral("pb_supprimer_employe"));
        pb_supprimer_employe->setGeometry(QRect(320, 110, 91, 41));
        pb_supprimer_employe->setFont(font);
        pb_supprimer_employe->setStyleSheet(QLatin1String("background-color: black	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        pushButton_10 = new QPushButton(groupBox_5);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(310, 400, 91, 41));
        pushButton_10->setFont(font1);
        pushButton_10->setAutoFillBackground(false);
        pushButton_10->setStyleSheet(QLatin1String("background-color: #8B0000	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        cb_id_supp = new QComboBox(groupBox_5);
        cb_id_supp->setObjectName(QStringLiteral("cb_id_supp"));
        cb_id_supp->setGeometry(QRect(130, 111, 121, 41));
        cb_id_supp->setStyleSheet(QLatin1String("background-color:rgb(255,222,227);\n"
"  color: black;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));
        idArd = new QLabel(groupBox_5);
        idArd->setObjectName(QStringLiteral("idArd"));
        idArd->setGeometry(QRect(590, 100, 56, 16));
        nomArd = new QLabel(groupBox_5);
        nomArd->setObjectName(QStringLiteral("nomArd"));
        nomArd->setGeometry(QRect(590, 140, 56, 16));
        RFIDard = new QLabel(groupBox_5);
        RFIDard->setObjectName(QStringLiteral("RFIDard"));
        RFIDard->setGeometry(QRect(590, 170, 56, 16));
        label = new QLabel(groupBox_5);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(500, 100, 56, 16));
        label_20 = new QLabel(groupBox_5);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(490, 140, 56, 16));
        label_21 = new QLabel(groupBox_5);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(490, 170, 56, 16));
        ER = new QLabel(groupBox_5);
        ER->setObjectName(QStringLiteral("ER"));
        ER->setGeometry(QRect(340, 280, 56, 16));
        tabWidget_2->addTab(supp_cl, QString());

        retranslateUi(gerer_employes);

        tabWidget_2->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(gerer_employes);
    } // setupUi

    void retranslateUi(QDialog *gerer_employes)
    {
        gerer_employes->setWindowTitle(QApplication::translate("gerer_employes", "Dialog", Q_NULLPTR));
        ajout_cl->setTitle(QString());
        lineEdit_3->setText(QApplication::translate("gerer_employes", "Affichage des Employ\303\251es", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("gerer_employes", "quitter", Q_NULLPTR));
        pb_ajout_em->setText(QApplication::translate("gerer_employes", "Ajouter", Q_NULLPTR));
        label_5->setText(QApplication::translate("gerer_employes", "adresse :", Q_NULLPTR));
        le_prenom->setText(QString());
        le_salaire->setText(QString());
        label_3->setText(QApplication::translate("gerer_employes", "Salaire", Q_NULLPTR));
        label_2->setText(QApplication::translate("gerer_employes", "id", Q_NULLPTR));
        le_mail->setText(QString());
        label_4->setText(QApplication::translate("gerer_employes", "Mail", Q_NULLPTR));
        label_6->setText(QApplication::translate("gerer_employes", "Nom", Q_NULLPTR));
        label_8->setText(QApplication::translate("gerer_employes", "Prenom", Q_NULLPTR));
        cb_genre->clear();
        cb_genre->insertItems(0, QStringList()
         << QApplication::translate("gerer_employes", "femme", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "homme", Q_NULLPTR)
        );
        label_7->setText(QApplication::translate("gerer_employes", "genre", Q_NULLPTR));
        label_14->setText(QApplication::translate("gerer_employes", "Recherche par :", Q_NULLPTR));
        label_34->setText(QApplication::translate("gerer_employes", "trier ", Q_NULLPTR));
        cb_tri->clear();
        cb_tri->insertItems(0, QStringList()
         << QApplication::translate("gerer_employes", "choisir", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "nom croissants", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "nom decroissants", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "prenom croissants", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "prenom decroissant", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "salaire croissant", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "salaire decroissant", Q_NULLPTR)
        );
        cb_rech_emp->clear();
        cb_rech_emp->insertItems(0, QStringList()
         << QApplication::translate("gerer_employes", "choisir", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "id", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "nom", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "salaire", Q_NULLPTR)
        );
        le_rech->setText(QString());
        search_pb->setText(QApplication::translate("gerer_employes", "rechercher", Q_NULLPTR));
        pushButton->setText(QApplication::translate("gerer_employes", "G\303\251n\303\251rer PDF", Q_NULLPTR));
        label_35->setText(QApplication::translate("gerer_employes", "id :", Q_NULLPTR));
        pb_stat->setText(QApplication::translate("gerer_employes", "Statistiques", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("gerer_employes", "chat", Q_NULLPTR));
        tabWidget_2->setTabText(tabWidget_2->indexOf(modif_cl), QApplication::translate("gerer_employes", "ajouter des employ\303\251es", Q_NULLPTR));
        groupBox_3->setTitle(QString());
        label_9->setText(QApplication::translate("gerer_employes", "choisir  l'identifiant de l'employ\303\251 \303\240 modifier:", Q_NULLPTR));
        label_10->setText(QApplication::translate("gerer_employes", "id employ\303\251", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("gerer_employes", "quitter", Q_NULLPTR));
        pb_modif_emp->setText(QApplication::translate("gerer_employes", "modifier", Q_NULLPTR));
        le_salaire_modif->setText(QString());
        le_prenom_modif->setText(QString());
        label_13->setText(QApplication::translate("gerer_employes", "Prenom", Q_NULLPTR));
        label_15->setText(QApplication::translate("gerer_employes", "Mail", Q_NULLPTR));
        label_18->setText(QApplication::translate("gerer_employes", "adresse :", Q_NULLPTR));
        label_11->setText(QApplication::translate("gerer_employes", "Nom", Q_NULLPTR));
        label_12->setText(QApplication::translate("gerer_employes", "Salaire", Q_NULLPTR));
        le_mail_modif->setText(QString());
        label_19->setText(QApplication::translate("gerer_employes", "genre", Q_NULLPTR));
        cb_genre_modif->clear();
        cb_genre_modif->insertItems(0, QStringList()
         << QApplication::translate("gerer_employes", "femme", Q_NULLPTR)
         << QApplication::translate("gerer_employes", "homme", Q_NULLPTR)
        );
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_4), QApplication::translate("gerer_employes", "modifier un employ\303\251", Q_NULLPTR));
        groupBox_5->setTitle(QString());
        label_16->setText(QApplication::translate("gerer_employes", "choisir l'identifiant de l'employ\303\251 \303\240 supprimer:", Q_NULLPTR));
        label_17->setText(QApplication::translate("gerer_employes", "id", Q_NULLPTR));
        pb_supprimer_employe->setText(QApplication::translate("gerer_employes", "supprimer", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("gerer_employes", "quitter", Q_NULLPTR));
        idArd->setText(QApplication::translate("gerer_employes", "TextLabel", Q_NULLPTR));
        nomArd->setText(QApplication::translate("gerer_employes", "TextLabel", Q_NULLPTR));
        RFIDard->setText(QApplication::translate("gerer_employes", "TextLabel", Q_NULLPTR));
        label->setText(QApplication::translate("gerer_employes", "ID :", Q_NULLPTR));
        label_20->setText(QApplication::translate("gerer_employes", "Nom :", Q_NULLPTR));
        label_21->setText(QApplication::translate("gerer_employes", "RFID :", Q_NULLPTR));
        ER->setText(QApplication::translate("gerer_employes", "TextLabel", Q_NULLPTR));
        tabWidget_2->setTabText(tabWidget_2->indexOf(supp_cl), QApplication::translate("gerer_employes", "supprimer un employ\303\251", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class gerer_employes: public Ui_gerer_employes {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GERER_EMPLOYES_H
