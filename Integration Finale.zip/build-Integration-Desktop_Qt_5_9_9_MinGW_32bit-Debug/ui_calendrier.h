/********************************************************************************
** Form generated from reading UI file 'calendrier.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALENDRIER_H
#define UI_CALENDRIER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Calendrier
{
public:
    QWidget *centralwidget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Calendrier)
    {
        if (Calendrier->objectName().isEmpty())
            Calendrier->setObjectName(QStringLiteral("Calendrier"));
        Calendrier->resize(800, 527);
        Calendrier->setStyleSheet(QStringLiteral("background-image: url(\"C:/Users/Ahmed Ben Abid/Downloads/ffii.png\");"));
        centralwidget = new QWidget(Calendrier);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        Calendrier->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Calendrier);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 30));
        Calendrier->setMenuBar(menubar);
        statusbar = new QStatusBar(Calendrier);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Calendrier->setStatusBar(statusbar);

        retranslateUi(Calendrier);

        QMetaObject::connectSlotsByName(Calendrier);
    } // setupUi

    void retranslateUi(QMainWindow *Calendrier)
    {
        Calendrier->setWindowTitle(QApplication::translate("Calendrier", "MainWindow", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Calendrier: public Ui_Calendrier {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALENDRIER_H
