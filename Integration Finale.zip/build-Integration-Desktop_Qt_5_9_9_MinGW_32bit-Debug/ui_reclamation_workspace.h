/********************************************************************************
** Form generated from reading UI file 'reclamation_workspace.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECLAMATION_WORKSPACE_H
#define UI_RECLAMATION_WORKSPACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_reclamation_workspace
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QLineEdit *recherche;
    QTableView *tableau;
    QGroupBox *groupBox;
    QSpinBox *code;
    QComboBox *type;
    QComboBox *client;
    QTextEdit *description;
    QDateEdit *dateEdit;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QPushButton *add;
    QPushButton *update;
    QPushButton *delete_2;
    QPushButton *camera;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLineEdit *sms;
    QComboBox *comboBox;
    QPushButton *pushButton_4;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *reclamation_workspace)
    {
        if (reclamation_workspace->objectName().isEmpty())
            reclamation_workspace->setObjectName(QStringLiteral("reclamation_workspace"));
        reclamation_workspace->resize(1173, 700);
        centralwidget = new QWidget(reclamation_workspace);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(20, 30, 981, 531));
        tabWidget->setTabPosition(QTabWidget::West);
        tabWidget->setTabShape(QTabWidget::Triangular);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        recherche = new QLineEdit(tab);
        recherche->setObjectName(QStringLiteral("recherche"));
        recherche->setGeometry(QRect(746, 20, 191, 24));
        recherche->setClearButtonEnabled(true);
        tableau = new QTableView(tab);
        tableau->setObjectName(QStringLiteral("tableau"));
        tableau->setGeometry(QRect(446, 61, 491, 331));
        tableau->setSortingEnabled(true);
        tableau->horizontalHeader()->setCascadingSectionResizes(true);
        tableau->horizontalHeader()->setProperty("showSortIndicator", QVariant(false));
        tableau->horizontalHeader()->setStretchLastSection(false);
        groupBox = new QGroupBox(tab);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(20, 60, 401, 431));
        code = new QSpinBox(groupBox);
        code->setObjectName(QStringLiteral("code"));
        code->setGeometry(QRect(201, 50, 161, 22));
        type = new QComboBox(groupBox);
        type->setObjectName(QStringLiteral("type"));
        type->setGeometry(QRect(202, 90, 161, 22));
        client = new QComboBox(groupBox);
        client->setObjectName(QStringLiteral("client"));
        client->setGeometry(QRect(200, 130, 161, 22));
        description = new QTextEdit(groupBox);
        description->setObjectName(QStringLiteral("description"));
        description->setGeometry(QRect(200, 220, 161, 87));
        dateEdit = new QDateEdit(groupBox);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(199, 170, 161, 22));
        dateEdit->setCalendarPopup(true);
        label = new QLabel(groupBox);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 50, 111, 16));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 90, 56, 16));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(30, 140, 56, 16));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(20, 190, 56, 16));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(20, 240, 111, 16));
        add = new QPushButton(groupBox);
        add->setObjectName(QStringLiteral("add"));
        add->setGeometry(QRect(10, 340, 93, 28));
        update = new QPushButton(groupBox);
        update->setObjectName(QStringLiteral("update"));
        update->setGeometry(QRect(120, 340, 93, 28));
        delete_2 = new QPushButton(groupBox);
        delete_2->setObjectName(QStringLiteral("delete_2"));
        delete_2->setGeometry(QRect(240, 340, 93, 28));
        camera = new QPushButton(groupBox);
        camera->setObjectName(QStringLiteral("camera"));
        camera->setGeometry(QRect(10, 390, 93, 28));
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(120, 390, 121, 23));
        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(260, 390, 91, 23));
        pushButton_3 = new QPushButton(tab);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(840, 410, 93, 28));
        sms = new QLineEdit(tab);
        sms->setObjectName(QStringLiteral("sms"));
        sms->setGeometry(QRect(450, 410, 381, 22));
        comboBox = new QComboBox(tab);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(612, 20, 121, 22));
        pushButton_4 = new QPushButton(tab);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(40, 10, 93, 28));
        tabWidget->addTab(tab, QString());
        reclamation_workspace->setCentralWidget(centralwidget);
        menubar = new QMenuBar(reclamation_workspace);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1173, 26));
        reclamation_workspace->setMenuBar(menubar);
        statusbar = new QStatusBar(reclamation_workspace);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        reclamation_workspace->setStatusBar(statusbar);

        retranslateUi(reclamation_workspace);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(reclamation_workspace);
    } // setupUi

    void retranslateUi(QMainWindow *reclamation_workspace)
    {
        reclamation_workspace->setWindowTitle(QApplication::translate("reclamation_workspace", "MainWindow", Q_NULLPTR));
        recherche->setPlaceholderText(QApplication::translate("reclamation_workspace", "Recherche", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("reclamation_workspace", "Form", Q_NULLPTR));
        type->clear();
        type->insertItems(0, QStringList()
         << QApplication::translate("reclamation_workspace", "Type1", Q_NULLPTR)
         << QApplication::translate("reclamation_workspace", "Type2", Q_NULLPTR)
         << QApplication::translate("reclamation_workspace", "Type3", Q_NULLPTR)
        );
        label->setText(QApplication::translate("reclamation_workspace", "ID Reclamation", Q_NULLPTR));
        label_2->setText(QApplication::translate("reclamation_workspace", "Type", Q_NULLPTR));
        label_3->setText(QApplication::translate("reclamation_workspace", "Client", Q_NULLPTR));
        label_4->setText(QApplication::translate("reclamation_workspace", "Date", Q_NULLPTR));
        label_5->setText(QApplication::translate("reclamation_workspace", "Description", Q_NULLPTR));
        add->setText(QApplication::translate("reclamation_workspace", "Add", Q_NULLPTR));
        update->setText(QApplication::translate("reclamation_workspace", "Update", Q_NULLPTR));
        delete_2->setText(QApplication::translate("reclamation_workspace", "Delete", Q_NULLPTR));
        camera->setText(QApplication::translate("reclamation_workspace", "Camera", Q_NULLPTR));
        pushButton->setText(QApplication::translate("reclamation_workspace", "stat combo", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("reclamation_workspace", "export PDF", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("reclamation_workspace", "Send", Q_NULLPTR));
        sms->setPlaceholderText(QApplication::translate("reclamation_workspace", "sms text ...", Q_NULLPTR));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("reclamation_workspace", "All", Q_NULLPTR)
         << QApplication::translate("reclamation_workspace", "ID_reclamation", Q_NULLPTR)
         << QApplication::translate("reclamation_workspace", "Type", Q_NULLPTR)
         << QApplication::translate("reclamation_workspace", "Client", Q_NULLPTR)
         << QApplication::translate("reclamation_workspace", "Date", Q_NULLPTR)
         << QApplication::translate("reclamation_workspace", "Description", Q_NULLPTR)
        );
        pushButton_4->setText(QApplication::translate("reclamation_workspace", "< Back", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("reclamation_workspace", "crud", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class reclamation_workspace: public Ui_reclamation_workspace {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECLAMATION_WORKSPACE_H
