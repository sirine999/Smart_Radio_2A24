/********************************************************************************
** Form generated from reading UI file 'dialoginvite.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGINVITE_H
#define UI_DIALOGINVITE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DialogInvite
{
public:
    QStackedWidget *stackedWidget;
    QWidget *page;
    QLineEdit *nom;
    QLabel *mail_2;
    QLabel *nom_2;
    QLabel *id_2;
    QLineEdit *id;
    QPushButton *confirmerajout;
    QPushButton *annulerajout;
    QLineEdit *mail;
    QLabel *adresse_2;
    QLineEdit *adresse;
    QLineEdit *prenom;
    QLabel *prenom_2;
    QLabel *programme_2;
    QLineEdit *programme;
    QLabel *label_2;
    QDateEdit *dateAjout;
    QWidget *page_2;
    QPushButton *pushButton_13;
    QLabel *label_14;
    QLineEdit *rech;
    QTableView *tableView;
    QLabel *label;
    QPushButton *modif;
    QComboBox *comboBox;
    QPushButton *ajoutaff;
    QPushButton *sup;
    QPushButton *capture;
    QPushButton *pushButton;
    QLabel *labela;
    QLabel *labelaa;
    QWidget *page_5;
    QPushButton *modifier;
    QPushButton *annulermodif;
    QLabel *label_7;
    QLabel *nom_3;
    QLabel *id_3;
    QLineEdit *mail_3;
    QLabel *programme_3;
    QLineEdit *id_4;
    QLabel *prenom_3;
    QLineEdit *adresse_3;
    QLineEdit *programme_4;
    QLabel *adresse_4;
    QLineEdit *nom_4;
    QLineEdit *prenom_4;
    QLabel *mail_4;
    QDateEdit *dateEdit;
    QWidget *page_6;
    QLabel *label_8;
    QLineEdit *idsupp;
    QPushButton *pushButton_21;
    QLabel *label_31;
    QPushButton *confirmersup;
    QPushButton *pushButton_2;

    void setupUi(QDialog *DialogInvite)
    {
        if (DialogInvite->objectName().isEmpty())
            DialogInvite->setObjectName(QStringLiteral("DialogInvite"));
        DialogInvite->resize(1154, 667);
        stackedWidget = new QStackedWidget(DialogInvite);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 40, 1151, 621));
        stackedWidget->setStyleSheet(QLatin1String("background-color: rgb(255, 222, 227);\n"
""));
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        nom = new QLineEdit(page);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(150, 120, 151, 25));
        nom->setStyleSheet(QStringLiteral("background-color:white;"));
        mail_2 = new QLabel(page);
        mail_2->setObjectName(QStringLiteral("mail_2"));
        mail_2->setGeometry(QRect(630, 180, 71, 20));
        QFont font;
        font.setFamily(QStringLiteral("Berlin Sans FB"));
        font.setPointSize(10);
        font.setBold(false);
        font.setWeight(50);
        mail_2->setFont(font);
        nom_2 = new QLabel(page);
        nom_2->setObjectName(QStringLiteral("nom_2"));
        nom_2->setGeometry(QRect(90, 120, 61, 20));
        nom_2->setFont(font);
        id_2 = new QLabel(page);
        id_2->setObjectName(QStringLiteral("id_2"));
        id_2->setGeometry(QRect(90, 180, 51, 20));
        id_2->setFont(font);
        id = new QLineEdit(page);
        id->setObjectName(QStringLiteral("id"));
        id->setGeometry(QRect(150, 180, 151, 25));
        id->setStyleSheet(QStringLiteral("background-color:white;"));
        confirmerajout = new QPushButton(page);
        confirmerajout->setObjectName(QStringLiteral("confirmerajout"));
        confirmerajout->setGeometry(QRect(660, 550, 141, 41));
        QFont font1;
        font1.setFamily(QStringLiteral("Berlin Sans FB"));
        font1.setPointSize(14);
        confirmerajout->setFont(font1);
        annulerajout = new QPushButton(page);
        annulerajout->setObjectName(QStringLiteral("annulerajout"));
        annulerajout->setGeometry(QRect(870, 550, 141, 41));
        annulerajout->setFont(font1);
        mail = new QLineEdit(page);
        mail->setObjectName(QStringLiteral("mail"));
        mail->setGeometry(QRect(720, 180, 151, 25));
        mail->setStyleSheet(QStringLiteral("background-color:white;"));
        adresse_2 = new QLabel(page);
        adresse_2->setObjectName(QStringLiteral("adresse_2"));
        adresse_2->setGeometry(QRect(330, 180, 91, 20));
        adresse_2->setFont(font);
        adresse = new QLineEdit(page);
        adresse->setObjectName(QStringLiteral("adresse"));
        adresse->setGeometry(QRect(420, 180, 151, 25));
        adresse->setStyleSheet(QStringLiteral("background-color:white;"));
        prenom = new QLineEdit(page);
        prenom->setObjectName(QStringLiteral("prenom"));
        prenom->setGeometry(QRect(420, 120, 151, 25));
        prenom->setStyleSheet(QStringLiteral("background-color:white;"));
        prenom_2 = new QLabel(page);
        prenom_2->setObjectName(QStringLiteral("prenom_2"));
        prenom_2->setGeometry(QRect(330, 120, 81, 20));
        prenom_2->setFont(font);
        programme_2 = new QLabel(page);
        programme_2->setObjectName(QStringLiteral("programme_2"));
        programme_2->setGeometry(QRect(610, 120, 111, 21));
        programme_2->setFont(font);
        programme = new QLineEdit(page);
        programme->setObjectName(QStringLiteral("programme"));
        programme->setGeometry(QRect(720, 120, 151, 25));
        programme->setStyleSheet(QLatin1String("background-color:white;\n"
""));
        label_2 = new QLabel(page);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(430, 20, 241, 51));
        QFont font2;
        font2.setPointSize(14);
        font2.setBold(true);
        font2.setWeight(75);
        label_2->setFont(font2);
        dateAjout = new QDateEdit(page);
        dateAjout->setObjectName(QStringLiteral("dateAjout"));
        dateAjout->setGeometry(QRect(709, 424, 281, 51));
        QFont font3;
        font3.setPointSize(14);
        font3.setStrikeOut(false);
        dateAjout->setFont(font3);
        dateAjout->setAlignment(Qt::AlignCenter);
        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        pushButton_13 = new QPushButton(page_2);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(930, 530, 131, 41));
        pushButton_13->setFont(font1);
        label_14 = new QLabel(page_2);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(130, 130, 91, 20));
        label_14->setFont(font);
        rech = new QLineEdit(page_2);
        rech->setObjectName(QStringLiteral("rech"));
        rech->setGeometry(QRect(240, 130, 151, 25));
        rech->setStyleSheet(QStringLiteral("background-color:white;"));
        tableView = new QTableView(page_2);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(120, 170, 941, 251));
        tableView->setStyleSheet(QStringLiteral("background-color:white;"));
        label = new QLabel(page_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(420, 20, 251, 51));
        label->setFont(font2);
        modif = new QPushButton(page_2);
        modif->setObjectName(QStringLiteral("modif"));
        modif->setGeometry(QRect(140, 520, 151, 41));
        modif->setFont(font1);
        comboBox = new QComboBox(page_2);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(940, 120, 131, 31));
        ajoutaff = new QPushButton(page_2);
        ajoutaff->setObjectName(QStringLiteral("ajoutaff"));
        ajoutaff->setGeometry(QRect(340, 520, 141, 41));
        ajoutaff->setFont(font1);
        sup = new QPushButton(page_2);
        sup->setObjectName(QStringLiteral("sup"));
        sup->setGeometry(QRect(140, 450, 141, 41));
        sup->setFont(font1);
        capture = new QPushButton(page_2);
        capture->setObjectName(QStringLiteral("capture"));
        capture->setGeometry(QRect(340, 450, 141, 41));
        capture->setFont(font1);
        pushButton = new QPushButton(page_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(790, 120, 112, 34));
        labela = new QLabel(page_2);
        labela->setObjectName(QStringLiteral("labela"));
        labela->setGeometry(QRect(670, 470, 241, 71));
        labelaa = new QLabel(page_2);
        labelaa->setObjectName(QStringLiteral("labelaa"));
        labelaa->setGeometry(QRect(590, 560, 69, 20));
        stackedWidget->addWidget(page_2);
        page_5 = new QWidget();
        page_5->setObjectName(QStringLiteral("page_5"));
        modifier = new QPushButton(page_5);
        modifier->setObjectName(QStringLiteral("modifier"));
        modifier->setGeometry(QRect(370, 430, 151, 41));
        modifier->setFont(font1);
        annulermodif = new QPushButton(page_5);
        annulermodif->setObjectName(QStringLiteral("annulermodif"));
        annulermodif->setGeometry(QRect(550, 430, 181, 41));
        annulermodif->setFont(font1);
        annulermodif->setStyleSheet(QStringLiteral(""));
        label_7 = new QLabel(page_5);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(400, 50, 361, 51));
        label_7->setFont(font2);
        nom_3 = new QLabel(page_5);
        nom_3->setObjectName(QStringLiteral("nom_3"));
        nom_3->setGeometry(QRect(110, 230, 61, 20));
        nom_3->setFont(font);
        id_3 = new QLabel(page_5);
        id_3->setObjectName(QStringLiteral("id_3"));
        id_3->setGeometry(QRect(110, 290, 51, 20));
        id_3->setFont(font);
        mail_3 = new QLineEdit(page_5);
        mail_3->setObjectName(QStringLiteral("mail_3"));
        mail_3->setGeometry(QRect(740, 290, 151, 25));
        mail_3->setStyleSheet(QStringLiteral("background-color:white;"));
        programme_3 = new QLabel(page_5);
        programme_3->setObjectName(QStringLiteral("programme_3"));
        programme_3->setGeometry(QRect(630, 230, 111, 21));
        programme_3->setFont(font);
        id_4 = new QLineEdit(page_5);
        id_4->setObjectName(QStringLiteral("id_4"));
        id_4->setGeometry(QRect(170, 290, 151, 25));
        id_4->setStyleSheet(QStringLiteral("background-color:white;"));
        prenom_3 = new QLabel(page_5);
        prenom_3->setObjectName(QStringLiteral("prenom_3"));
        prenom_3->setGeometry(QRect(350, 230, 81, 20));
        prenom_3->setFont(font);
        adresse_3 = new QLineEdit(page_5);
        adresse_3->setObjectName(QStringLiteral("adresse_3"));
        adresse_3->setGeometry(QRect(440, 290, 151, 25));
        adresse_3->setStyleSheet(QStringLiteral("background-color:white;"));
        programme_4 = new QLineEdit(page_5);
        programme_4->setObjectName(QStringLiteral("programme_4"));
        programme_4->setGeometry(QRect(740, 230, 151, 25));
        programme_4->setStyleSheet(QLatin1String("background-color:white;\n"
""));
        adresse_4 = new QLabel(page_5);
        adresse_4->setObjectName(QStringLiteral("adresse_4"));
        adresse_4->setGeometry(QRect(350, 290, 91, 20));
        adresse_4->setFont(font);
        nom_4 = new QLineEdit(page_5);
        nom_4->setObjectName(QStringLiteral("nom_4"));
        nom_4->setGeometry(QRect(170, 230, 151, 25));
        nom_4->setStyleSheet(QStringLiteral("background-color:white;"));
        prenom_4 = new QLineEdit(page_5);
        prenom_4->setObjectName(QStringLiteral("prenom_4"));
        prenom_4->setGeometry(QRect(440, 230, 151, 25));
        prenom_4->setStyleSheet(QStringLiteral("background-color:white;"));
        mail_4 = new QLabel(page_5);
        mail_4->setObjectName(QStringLiteral("mail_4"));
        mail_4->setGeometry(QRect(650, 290, 71, 20));
        mail_4->setFont(font);
        dateEdit = new QDateEdit(page_5);
        dateEdit->setObjectName(QStringLiteral("dateEdit"));
        dateEdit->setGeometry(QRect(400, 350, 301, 61));
        dateEdit->setAlignment(Qt::AlignCenter);
        stackedWidget->addWidget(page_5);
        page_6 = new QWidget();
        page_6->setObjectName(QStringLiteral("page_6"));
        label_8 = new QLabel(page_6);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(410, 60, 351, 51));
        label_8->setFont(font2);
        idsupp = new QLineEdit(page_6);
        idsupp->setObjectName(QStringLiteral("idsupp"));
        idsupp->setGeometry(QRect(560, 220, 81, 31));
        idsupp->setStyleSheet(QStringLiteral("background-color:white;"));
        pushButton_21 = new QPushButton(page_6);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        pushButton_21->setGeometry(QRect(650, 330, 181, 41));
        pushButton_21->setFont(font1);
        label_31 = new QLabel(page_6);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(500, 220, 51, 20));
        label_31->setFont(font);
        confirmersup = new QPushButton(page_6);
        confirmersup->setObjectName(QStringLiteral("confirmersup"));
        confirmersup->setGeometry(QRect(380, 330, 181, 41));
        confirmersup->setFont(font1);
        stackedWidget->addWidget(page_6);
        pushButton_2 = new QPushButton(DialogInvite);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(0, 0, 131, 41));

        retranslateUi(DialogInvite);

        stackedWidget->setCurrentIndex(3);


        QMetaObject::connectSlotsByName(DialogInvite);
    } // setupUi

    void retranslateUi(QDialog *DialogInvite)
    {
        DialogInvite->setWindowTitle(QApplication::translate("DialogInvite", "Dialog", Q_NULLPTR));
        mail_2->setText(QApplication::translate("DialogInvite", "   Mail", Q_NULLPTR));
        nom_2->setText(QApplication::translate("DialogInvite", "  Nom", Q_NULLPTR));
        id_2->setText(QApplication::translate("DialogInvite", "    ID", Q_NULLPTR));
        confirmerajout->setText(QApplication::translate("DialogInvite", "Ajouter", Q_NULLPTR));
        annulerajout->setText(QApplication::translate("DialogInvite", "Annnuler", Q_NULLPTR));
        adresse_2->setText(QApplication::translate("DialogInvite", "  Adresse ", Q_NULLPTR));
        prenom_2->setText(QApplication::translate("DialogInvite", "  Prenom", Q_NULLPTR));
        programme_2->setText(QApplication::translate("DialogInvite", "Programme", Q_NULLPTR));
        label_2->setText(QApplication::translate("DialogInvite", "Cr\303\251ation invit\303\251s", Q_NULLPTR));
        pushButton_13->setText(QApplication::translate("DialogInvite", "refresh", Q_NULLPTR));
        label_14->setText(QApplication::translate("DialogInvite", "Recherche:", Q_NULLPTR));
        label->setText(QApplication::translate("DialogInvite", "Affichage invit\303\251s", Q_NULLPTR));
        modif->setText(QApplication::translate("DialogInvite", "Modifier", Q_NULLPTR));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("DialogInvite", "Tri par:", Q_NULLPTR)
         << QApplication::translate("DialogInvite", "ID desc", Q_NULLPTR)
         << QApplication::translate("DialogInvite", "ID", Q_NULLPTR)
         << QApplication::translate("DialogInvite", "NOM desc", Q_NULLPTR)
         << QApplication::translate("DialogInvite", "NOM", Q_NULLPTR)
         << QApplication::translate("DialogInvite", "PRENOM desc", Q_NULLPTR)
         << QApplication::translate("DialogInvite", "PRENOM", Q_NULLPTR)
        );
        ajoutaff->setText(QApplication::translate("DialogInvite", "Ajouter", Q_NULLPTR));
        sup->setText(QApplication::translate("DialogInvite", "Supprimer", Q_NULLPTR));
        capture->setText(QApplication::translate("DialogInvite", "Capture", Q_NULLPTR));
        pushButton->setText(QApplication::translate("DialogInvite", "Calendrier", Q_NULLPTR));
        labela->setText(QApplication::translate("DialogInvite", "TextLabel", Q_NULLPTR));
        labelaa->setText(QApplication::translate("DialogInvite", "TextLabel", Q_NULLPTR));
        modifier->setText(QApplication::translate("DialogInvite", "Modifier", Q_NULLPTR));
        annulermodif->setText(QApplication::translate("DialogInvite", "Annuler", Q_NULLPTR));
        label_7->setText(QApplication::translate("DialogInvite", "Mettre \303\240 jour des invit\303\251s", Q_NULLPTR));
        nom_3->setText(QApplication::translate("DialogInvite", "  Nom", Q_NULLPTR));
        id_3->setText(QApplication::translate("DialogInvite", "    ID", Q_NULLPTR));
        programme_3->setText(QApplication::translate("DialogInvite", "Programme", Q_NULLPTR));
        prenom_3->setText(QApplication::translate("DialogInvite", "  Prenom", Q_NULLPTR));
        adresse_4->setText(QApplication::translate("DialogInvite", "  Adresse ", Q_NULLPTR));
        mail_4->setText(QApplication::translate("DialogInvite", "   Mail", Q_NULLPTR));
        label_8->setText(QApplication::translate("DialogInvite", "Suppression des invit\303\251s", Q_NULLPTR));
        pushButton_21->setText(QApplication::translate("DialogInvite", "Annuler", Q_NULLPTR));
        label_31->setText(QApplication::translate("DialogInvite", "    ID", Q_NULLPTR));
        confirmersup->setText(QApplication::translate("DialogInvite", "Supprimer", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("DialogInvite", "Retour", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class DialogInvite: public Ui_DialogInvite {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGINVITE_H
