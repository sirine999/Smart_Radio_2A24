/********************************************************************************
** Form generated from reading UI file 'statistiques.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIQUES_H
#define UI_STATISTIQUES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_statistiques
{
public:
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton_11;

    void setupUi(QDialog *statistiques)
    {
        if (statistiques->objectName().isEmpty())
            statistiques->setObjectName(QStringLiteral("statistiques"));
        statistiques->resize(983, 1010);
        label = new QLabel(statistiques);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(720, 360, 56, 16));
        label->setStyleSheet(QStringLiteral("color:blue;"));
        label_2 = new QLabel(statistiques);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(720, 450, 56, 16));
        label_2->setStyleSheet(QStringLiteral("color:green;"));
        pushButton_11 = new QPushButton(statistiques);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(420, 950, 101, 41));
        QFont font;
        font.setFamily(QStringLiteral("calibri"));
        font.setBold(true);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(75);
        font.setStrikeOut(false);
        font.setKerning(true);
        pushButton_11->setFont(font);
        pushButton_11->setAutoFillBackground(false);
        pushButton_11->setStyleSheet(QLatin1String("background-color: #8B0000	;\n"
"  color: white;\n"
"  padding: 10px;\n"
"  text-align: center;\n"
"font-family:calibri;\n"
"  font-size: 13px;\n"
"  margin: 2px 1px;\n"
"  border-radius : 16px;"));

        retranslateUi(statistiques);

        QMetaObject::connectSlotsByName(statistiques);
    } // setupUi

    void retranslateUi(QDialog *statistiques)
    {
        statistiques->setWindowTitle(QApplication::translate("statistiques", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("statistiques", "Homme", Q_NULLPTR));
        label_2->setText(QApplication::translate("statistiques", "Femme", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("statistiques", "quitter", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class statistiques: public Ui_statistiques {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIQUES_H
