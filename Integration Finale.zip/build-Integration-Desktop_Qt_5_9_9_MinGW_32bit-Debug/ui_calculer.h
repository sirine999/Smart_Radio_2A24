/********************************************************************************
** Form generated from reading UI file 'calculer.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALCULER_H
#define UI_CALCULER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Calculer
{
public:
    QWidget *centralwidget;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QGridLayout *gridLayout_5;
    QPushButton *Button9;
    QPushButton *Button0;
    QPushButton *Button3;
    QPushButton *Subtract;
    QPushButton *Button8;
    QPushButton *Equals;
    QPushButton *Button2;
    QPushButton *MemGet;
    QPushButton *Button5;
    QPushButton *Button7;
    QPushButton *ChangeSign;
    QPushButton *Button1;
    QPushButton *Multiply;
    QPushButton *MemAdd;
    QPushButton *Add;
    QPushButton *Button6;
    QPushButton *Clear;
    QPushButton *Divide;
    QPushButton *Button4;
    QPushButton *MemClear;
    QLineEdit *Display;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Calculer)
    {
        if (Calculer->objectName().isEmpty())
            Calculer->setObjectName(QStringLiteral("Calculer"));
        Calculer->resize(800, 600);
        centralwidget = new QWidget(Calculer);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        gridLayoutWidget = new QWidget(centralwidget);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(40, 30, 681, 451));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        gridLayout_5 = new QGridLayout();
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        Button9 = new QPushButton(gridLayoutWidget);
        Button9->setObjectName(QStringLiteral("Button9"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Button9->sizePolicy().hasHeightForWidth());
        Button9->setSizePolicy(sizePolicy);
        Button9->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button9, 0, 2, 1, 1);

        Button0 = new QPushButton(gridLayoutWidget);
        Button0->setObjectName(QStringLiteral("Button0"));
        sizePolicy.setHeightForWidth(Button0->sizePolicy().hasHeightForWidth());
        Button0->setSizePolicy(sizePolicy);
        Button0->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button0, 3, 1, 1, 1);

        Button3 = new QPushButton(gridLayoutWidget);
        Button3->setObjectName(QStringLiteral("Button3"));
        sizePolicy.setHeightForWidth(Button3->sizePolicy().hasHeightForWidth());
        Button3->setSizePolicy(sizePolicy);
        Button3->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button3, 2, 2, 1, 1);

        Subtract = new QPushButton(gridLayoutWidget);
        Subtract->setObjectName(QStringLiteral("Subtract"));
        sizePolicy.setHeightForWidth(Subtract->sizePolicy().hasHeightForWidth());
        Subtract->setSizePolicy(sizePolicy);
        Subtract->setStyleSheet(QLatin1String("QPushButton {\n"
"    background-color: rgb(170, 170, 255);\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Subtract, 3, 3, 1, 1);

        Button8 = new QPushButton(gridLayoutWidget);
        Button8->setObjectName(QStringLiteral("Button8"));
        sizePolicy.setHeightForWidth(Button8->sizePolicy().hasHeightForWidth());
        Button8->setSizePolicy(sizePolicy);
        Button8->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button8, 0, 1, 1, 1);

        Equals = new QPushButton(gridLayoutWidget);
        Equals->setObjectName(QStringLiteral("Equals"));
        sizePolicy.setHeightForWidth(Equals->sizePolicy().hasHeightForWidth());
        Equals->setSizePolicy(sizePolicy);
        Equals->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: rgb(170, 170, 255);\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Equals, 3, 4, 1, 1);

        Button2 = new QPushButton(gridLayoutWidget);
        Button2->setObjectName(QStringLiteral("Button2"));
        sizePolicy.setHeightForWidth(Button2->sizePolicy().hasHeightForWidth());
        Button2->setSizePolicy(sizePolicy);
        Button2->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button2, 2, 1, 1, 1);

        MemGet = new QPushButton(gridLayoutWidget);
        MemGet->setObjectName(QStringLiteral("MemGet"));
        sizePolicy.setHeightForWidth(MemGet->sizePolicy().hasHeightForWidth());
        MemGet->setSizePolicy(sizePolicy);
        MemGet->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: rgb(170, 170, 255);\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(MemGet, 2, 4, 1, 1);

        Button5 = new QPushButton(gridLayoutWidget);
        Button5->setObjectName(QStringLiteral("Button5"));
        sizePolicy.setHeightForWidth(Button5->sizePolicy().hasHeightForWidth());
        Button5->setSizePolicy(sizePolicy);
        Button5->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button5, 1, 1, 1, 1);

        Button7 = new QPushButton(gridLayoutWidget);
        Button7->setObjectName(QStringLiteral("Button7"));
        sizePolicy.setHeightForWidth(Button7->sizePolicy().hasHeightForWidth());
        Button7->setSizePolicy(sizePolicy);
        Button7->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button7, 0, 0, 1, 1);

        ChangeSign = new QPushButton(gridLayoutWidget);
        ChangeSign->setObjectName(QStringLiteral("ChangeSign"));
        sizePolicy.setHeightForWidth(ChangeSign->sizePolicy().hasHeightForWidth());
        ChangeSign->setSizePolicy(sizePolicy);
        ChangeSign->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(ChangeSign, 3, 2, 1, 1);

        Button1 = new QPushButton(gridLayoutWidget);
        Button1->setObjectName(QStringLiteral("Button1"));
        sizePolicy.setHeightForWidth(Button1->sizePolicy().hasHeightForWidth());
        Button1->setSizePolicy(sizePolicy);
        Button1->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button1, 2, 0, 1, 1);

        Multiply = new QPushButton(gridLayoutWidget);
        Multiply->setObjectName(QStringLiteral("Multiply"));
        sizePolicy.setHeightForWidth(Multiply->sizePolicy().hasHeightForWidth());
        Multiply->setSizePolicy(sizePolicy);
        Multiply->setStyleSheet(QLatin1String("QPushButton {\n"
"   background-color: rgb(170, 170, 255);\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Multiply, 1, 3, 1, 1);

        MemAdd = new QPushButton(gridLayoutWidget);
        MemAdd->setObjectName(QStringLiteral("MemAdd"));
        sizePolicy.setHeightForWidth(MemAdd->sizePolicy().hasHeightForWidth());
        MemAdd->setSizePolicy(sizePolicy);
        MemAdd->setStyleSheet(QLatin1String("QPushButton {\n"
"    background-color: rgb(170, 170, 255);\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(MemAdd, 0, 4, 1, 1);

        Add = new QPushButton(gridLayoutWidget);
        Add->setObjectName(QStringLiteral("Add"));
        sizePolicy.setHeightForWidth(Add->sizePolicy().hasHeightForWidth());
        Add->setSizePolicy(sizePolicy);
        Add->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: rgb(170, 170, 255);\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Add, 2, 3, 1, 1);

        Button6 = new QPushButton(gridLayoutWidget);
        Button6->setObjectName(QStringLiteral("Button6"));
        sizePolicy.setHeightForWidth(Button6->sizePolicy().hasHeightForWidth());
        Button6->setSizePolicy(sizePolicy);
        Button6->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button6, 1, 2, 1, 1);

        Clear = new QPushButton(gridLayoutWidget);
        Clear->setObjectName(QStringLiteral("Clear"));
        sizePolicy.setHeightForWidth(Clear->sizePolicy().hasHeightForWidth());
        Clear->setSizePolicy(sizePolicy);
        Clear->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Clear, 3, 0, 1, 1);

        Divide = new QPushButton(gridLayoutWidget);
        Divide->setObjectName(QStringLiteral("Divide"));
        sizePolicy.setHeightForWidth(Divide->sizePolicy().hasHeightForWidth());
        Divide->setSizePolicy(sizePolicy);
        Divide->setStyleSheet(QLatin1String("QPushButton {\n"
"	background-color: rgb(170, 170, 255);\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Divide, 0, 3, 1, 1);

        Button4 = new QPushButton(gridLayoutWidget);
        Button4->setObjectName(QStringLiteral("Button4"));
        sizePolicy.setHeightForWidth(Button4->sizePolicy().hasHeightForWidth());
        Button4->setSizePolicy(sizePolicy);
        Button4->setStyleSheet(QLatin1String("QPushButton {\n"
"     background-color: #C0C0C0; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(Button4, 1, 0, 1, 1);

        MemClear = new QPushButton(gridLayoutWidget);
        MemClear->setObjectName(QStringLiteral("MemClear"));
        sizePolicy.setHeightForWidth(MemClear->sizePolicy().hasHeightForWidth());
        MemClear->setSizePolicy(sizePolicy);
        MemClear->setStyleSheet(QLatin1String("QPushButton {\n"
"    background-color: rgb(170, 170, 255);\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-color: #A9A9A9; border: 1px solid gray;\n"
"	border-radius: 0px;\n"
"	padding: 5px;\n"
"}"));

        gridLayout_5->addWidget(MemClear, 1, 4, 1, 1);


        gridLayout->addLayout(gridLayout_5, 1, 0, 1, 1);

        Display = new QLineEdit(gridLayoutWidget);
        Display->setObjectName(QStringLiteral("Display"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(Display->sizePolicy().hasHeightForWidth());
        Display->setSizePolicy(sizePolicy1);
        QFont font;
        font.setFamily(QStringLiteral("Arial"));
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        Display->setFont(font);
        Display->setContextMenuPolicy(Qt::PreventContextMenu);
        Display->setLayoutDirection(Qt::LeftToRight);
        Display->setStyleSheet(QLatin1String("QLineEdit {\n"
"	background-color: rgb(255, 222, 227);\n"
"    \n"
"	color: #ffffff;}"));
        Display->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(Display, 0, 0, 1, 1);

        Calculer->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Calculer);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 26));
        Calculer->setMenuBar(menubar);
        statusbar = new QStatusBar(Calculer);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Calculer->setStatusBar(statusbar);

        retranslateUi(Calculer);

        QMetaObject::connectSlotsByName(Calculer);
    } // setupUi

    void retranslateUi(QMainWindow *Calculer)
    {
        Calculer->setWindowTitle(QApplication::translate("Calculer", "MainWindow", Q_NULLPTR));
        Button9->setText(QApplication::translate("Calculer", "9", Q_NULLPTR));
        Button0->setText(QApplication::translate("Calculer", "0", Q_NULLPTR));
        Button3->setText(QApplication::translate("Calculer", "3", Q_NULLPTR));
        Subtract->setText(QApplication::translate("Calculer", "-", Q_NULLPTR));
        Button8->setText(QApplication::translate("Calculer", "8", Q_NULLPTR));
        Equals->setText(QApplication::translate("Calculer", "=", Q_NULLPTR));
        Button2->setText(QApplication::translate("Calculer", "2", Q_NULLPTR));
        MemGet->setText(QApplication::translate("Calculer", "M", Q_NULLPTR));
        Button5->setText(QApplication::translate("Calculer", "5", Q_NULLPTR));
        Button7->setText(QApplication::translate("Calculer", "7", Q_NULLPTR));
        ChangeSign->setText(QApplication::translate("Calculer", "+/-", Q_NULLPTR));
        Button1->setText(QApplication::translate("Calculer", "1", Q_NULLPTR));
        Multiply->setText(QApplication::translate("Calculer", "*", Q_NULLPTR));
        MemAdd->setText(QApplication::translate("Calculer", "M+", Q_NULLPTR));
        Add->setText(QApplication::translate("Calculer", "+", Q_NULLPTR));
        Button6->setText(QApplication::translate("Calculer", "6", Q_NULLPTR));
        Clear->setText(QApplication::translate("Calculer", "AC", Q_NULLPTR));
        Divide->setText(QApplication::translate("Calculer", "/", Q_NULLPTR));
        Button4->setText(QApplication::translate("Calculer", "4", Q_NULLPTR));
        MemClear->setText(QApplication::translate("Calculer", "M-", Q_NULLPTR));
        Display->setText(QApplication::translate("Calculer", "0.0", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Calculer: public Ui_Calculer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALCULER_H
