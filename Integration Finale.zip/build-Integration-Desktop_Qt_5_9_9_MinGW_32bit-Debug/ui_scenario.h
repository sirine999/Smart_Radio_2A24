/********************************************************************************
** Form generated from reading UI file 'scenario.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCENARIO_H
#define UI_SCENARIO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_scenario
{
public:
    QLabel *label_5;
    QTableView *table_stock;
    QLineEdit *id;
    QLineEdit *labelaa;
    QLabel *labela;
    QLabel *label_2;
    QGroupBox *groupBox_11;
    QLabel *label_12;
    QLabel *label_4;
    QLineEdit *type;
    QLabel *label_3;
    QLineEdit *marque;

    void setupUi(QDialog *scenario)
    {
        if (scenario->objectName().isEmpty())
            scenario->setObjectName(QStringLiteral("scenario"));
        scenario->resize(1320, 649);
        label_5 = new QLabel(scenario);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(170, 130, 121, 21));
        QFont font;
        font.setFamily(QStringLiteral("Berlin Sans FB"));
        font.setPointSize(10);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        label_5->setFont(font);
        table_stock = new QTableView(scenario);
        table_stock->setObjectName(QStringLiteral("table_stock"));
        table_stock->setGeometry(QRect(600, 40, 461, 291));
        table_stock->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        id = new QLineEdit(scenario);
        id->setObjectName(QStringLiteral("id"));
        id->setGeometry(QRect(310, 130, 113, 22));
        id->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        labelaa = new QLineEdit(scenario);
        labelaa->setObjectName(QStringLiteral("labelaa"));
        labelaa->setGeometry(QRect(240, 370, 301, 51));
        labelaa->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        labela = new QLabel(scenario);
        labela->setObjectName(QStringLiteral("labela"));
        labela->setGeometry(QRect(770, 530, 291, 61));
        labela->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        label_2 = new QLabel(scenario);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(170, 180, 101, 21));
        label_2->setFont(font);
        groupBox_11 = new QGroupBox(scenario);
        groupBox_11->setObjectName(QStringLiteral("groupBox_11"));
        groupBox_11->setGeometry(QRect(170, 50, 391, 41));
        groupBox_11->setStyleSheet(QStringLiteral("background-color: rgb(255, 222, 227);"));
        label_12 = new QLabel(groupBox_11);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(60, 0, 211, 41));
        QFont font1;
        font1.setFamily(QStringLiteral("Berlin Sans FB"));
        font1.setPointSize(12);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        label_12->setFont(font1);
        label_12->setStyleSheet(QStringLiteral("font: 12pt \"Berlin Sans FB\";"));
        label_4 = new QLabel(scenario);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(190, 390, 41, 21));
        label_4->setFont(font);
        type = new QLineEdit(scenario);
        type->setObjectName(QStringLiteral("type"));
        type->setGeometry(QRect(310, 180, 113, 22));
        type->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        label_3 = new QLabel(scenario);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(160, 230, 101, 21));
        label_3->setFont(font);
        marque = new QLineEdit(scenario);
        marque->setObjectName(QStringLiteral("marque"));
        marque->setGeometry(QRect(310, 230, 113, 22));
        marque->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));

        retranslateUi(scenario);

        QMetaObject::connectSlotsByName(scenario);
    } // setupUi

    void retranslateUi(QDialog *scenario)
    {
        scenario->setWindowTitle(QApplication::translate("scenario", "Dialog", Q_NULLPTR));
        label_5->setText(QApplication::translate("scenario", "Id du stock", Q_NULLPTR));
        labela->setText(QApplication::translate("scenario", "TextLabel", Q_NULLPTR));
        label_2->setText(QApplication::translate("scenario", "type", Q_NULLPTR));
        groupBox_11->setTitle(QString());
        label_12->setText(QApplication::translate("scenario", "sc\303\251nario arduino", Q_NULLPTR));
        label_4->setText(QApplication::translate("scenario", "etat", Q_NULLPTR));
        label_3->setText(QApplication::translate("scenario", "d\303\251partement", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class scenario: public Ui_scenario {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCENARIO_H
