/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *Connexion;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *nomU_connexion;
    QLineEdit *mdpU_connexion;
    QPushButton *connexion;
    QTimeEdit *timeEdit;
    QWidget *tab_2;
    QLineEdit *mdpU_compte;
    QLabel *label_3;
    QLineEdit *nomU_compte;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *emailU_compte;
    QLabel *label_6;
    QLineEdit *mdpConf_compte;
    QPushButton *CreerCompte;
    QLineEdit *rfid_compte;
    QLabel *label_11;
    QComboBox *comboBox_type;
    QLabel *label_12;
    QWidget *tab_3;
    QPushButton *supprimerU;
    QLineEdit *affichage_nomU;
    QLineEdit *affichage_mdpU;
    QTableView *tab_users;
    QLineEdit *affichage_emailU;
    QPushButton *modifierU;
    QLabel *label_matricule_rec_4;
    QLabel *label_type_rec_5;
    QPushButton *refresh_users;
    QLabel *label_nom_rec_4;
    QLineEdit *affichage_rfid;
    QLabel *label_nom_rec_5;
    QLabel *label_type_rec_6;
    QLineEdit *affichage_type;
    QWidget *tab;
    QLineEdit *mdpU_new1;
    QLabel *label_7;
    QLineEdit *mdpU_new2;
    QLabel *label_8;
    QLineEdit *mdpU_old;
    QLabel *label_9;
    QPushButton *confirmer_reset;
    QLineEdit *nomU_reset;
    QLabel *label_10;
    QGroupBox *groupBox_11;
    QLabel *label_14;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1400, 750);
        MainWindow->setStyleSheet(QStringLiteral("background-image: url(:/new/picture/bjk.jpg);"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(50, 40, 1141, 581));
        tabWidget->setStyleSheet(QLatin1String("font: 12pt \"Berlin Sans FB\";\n"
"color: rgb(0, 0, 0);"));
        tabWidget->setTabShape(QTabWidget::Triangular);
        Connexion = new QWidget();
        Connexion->setObjectName(QStringLiteral("Connexion"));
        label = new QLabel(Connexion);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(20, 50, 151, 31));
        label->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_2 = new QLabel(Connexion);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(20, 100, 151, 31));
        label_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        nomU_connexion = new QLineEdit(Connexion);
        nomU_connexion->setObjectName(QStringLiteral("nomU_connexion"));
        nomU_connexion->setGeometry(QRect(190, 50, 171, 31));
        nomU_connexion->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpU_connexion = new QLineEdit(Connexion);
        mdpU_connexion->setObjectName(QStringLiteral("mdpU_connexion"));
        mdpU_connexion->setGeometry(QRect(190, 100, 171, 31));
        mdpU_connexion->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpU_connexion->setEchoMode(QLineEdit::Password);
        connexion = new QPushButton(Connexion);
        connexion->setObjectName(QStringLiteral("connexion"));
        connexion->setGeometry(QRect(190, 160, 111, 31));
        connexion->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        timeEdit = new QTimeEdit(Connexion);
        timeEdit->setObjectName(QStringLiteral("timeEdit"));
        timeEdit->setGeometry(QRect(120, 240, 118, 25));
        tabWidget->addTab(Connexion, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        mdpU_compte = new QLineEdit(tab_2);
        mdpU_compte->setObjectName(QStringLiteral("mdpU_compte"));
        mdpU_compte->setGeometry(QRect(220, 270, 151, 22));
        mdpU_compte->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpU_compte->setEchoMode(QLineEdit::Password);
        label_3 = new QLabel(tab_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(50, 180, 151, 16));
        label_3->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        nomU_compte = new QLineEdit(tab_2);
        nomU_compte->setObjectName(QStringLiteral("nomU_compte"));
        nomU_compte->setGeometry(QRect(220, 180, 151, 22));
        nomU_compte->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_4 = new QLabel(tab_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(90, 270, 121, 16));
        label_4->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_5 = new QLabel(tab_2);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(130, 220, 61, 20));
        label_5->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        emailU_compte = new QLineEdit(tab_2);
        emailU_compte->setObjectName(QStringLiteral("emailU_compte"));
        emailU_compte->setGeometry(QRect(220, 220, 231, 22));
        emailU_compte->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_6 = new QLabel(tab_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 320, 201, 20));
        label_6->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpConf_compte = new QLineEdit(tab_2);
        mdpConf_compte->setObjectName(QStringLiteral("mdpConf_compte"));
        mdpConf_compte->setGeometry(QRect(220, 320, 151, 22));
        mdpConf_compte->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpConf_compte->setEchoMode(QLineEdit::Password);
        CreerCompte = new QPushButton(tab_2);
        CreerCompte->setObjectName(QStringLiteral("CreerCompte"));
        CreerCompte->setGeometry(QRect(150, 440, 141, 28));
        CreerCompte->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        rfid_compte = new QLineEdit(tab_2);
        rfid_compte->setObjectName(QStringLiteral("rfid_compte"));
        rfid_compte->setGeometry(QRect(220, 370, 151, 22));
        rfid_compte->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        rfid_compte->setEchoMode(QLineEdit::Normal);
        label_11 = new QLabel(tab_2);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(160, 370, 51, 20));
        label_11->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        comboBox_type = new QComboBox(tab_2);
        comboBox_type->setObjectName(QStringLiteral("comboBox_type"));
        comboBox_type->setGeometry(QRect(222, 130, 91, 22));
        label_12 = new QLabel(tab_2);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(130, 130, 51, 16));
        label_12->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        supprimerU = new QPushButton(tab_3);
        supprimerU->setObjectName(QStringLiteral("supprimerU"));
        supprimerU->setGeometry(QRect(780, 410, 296, 28));
        supprimerU->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        affichage_nomU = new QLineEdit(tab_3);
        affichage_nomU->setObjectName(QStringLiteral("affichage_nomU"));
        affichage_nomU->setGeometry(QRect(888, 100, 113, 28));
        affichage_nomU->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        affichage_nomU->setReadOnly(true);
        affichage_mdpU = new QLineEdit(tab_3);
        affichage_mdpU->setObjectName(QStringLiteral("affichage_mdpU"));
        affichage_mdpU->setGeometry(QRect(888, 200, 113, 28));
        affichage_mdpU->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        tab_users = new QTableView(tab_3);
        tab_users->setObjectName(QStringLiteral("tab_users"));
        tab_users->setGeometry(QRect(10, 10, 641, 241));
        affichage_emailU = new QLineEdit(tab_3);
        affichage_emailU->setObjectName(QStringLiteral("affichage_emailU"));
        affichage_emailU->setGeometry(QRect(888, 150, 113, 28));
        affichage_emailU->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        affichage_emailU->setReadOnly(false);
        modifierU = new QPushButton(tab_3);
        modifierU->setObjectName(QStringLiteral("modifierU"));
        modifierU->setGeometry(QRect(780, 360, 296, 28));
        modifierU->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_matricule_rec_4 = new QLabel(tab_3);
        label_matricule_rec_4->setObjectName(QStringLiteral("label_matricule_rec_4"));
        label_matricule_rec_4->setGeometry(QRect(800, 150, 61, 20));
        label_matricule_rec_4->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_type_rec_5 = new QLabel(tab_3);
        label_type_rec_5->setObjectName(QStringLiteral("label_type_rec_5"));
        label_type_rec_5->setGeometry(QRect(730, 100, 151, 20));
        label_type_rec_5->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        refresh_users = new QPushButton(tab_3);
        refresh_users->setObjectName(QStringLiteral("refresh_users"));
        refresh_users->setGeometry(QRect(10, 260, 93, 28));
        refresh_users->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_nom_rec_4 = new QLabel(tab_3);
        label_nom_rec_4->setObjectName(QStringLiteral("label_nom_rec_4"));
        label_nom_rec_4->setGeometry(QRect(760, 200, 111, 20));
        label_nom_rec_4->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        affichage_rfid = new QLineEdit(tab_3);
        affichage_rfid->setObjectName(QStringLiteral("affichage_rfid"));
        affichage_rfid->setGeometry(QRect(890, 250, 113, 28));
        affichage_rfid->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_nom_rec_5 = new QLabel(tab_3);
        label_nom_rec_5->setObjectName(QStringLiteral("label_nom_rec_5"));
        label_nom_rec_5->setGeometry(QRect(820, 250, 41, 20));
        label_nom_rec_5->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_type_rec_6 = new QLabel(tab_3);
        label_type_rec_6->setObjectName(QStringLiteral("label_type_rec_6"));
        label_type_rec_6->setGeometry(QRect(790, 50, 41, 20));
        label_type_rec_6->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        affichage_type = new QLineEdit(tab_3);
        affichage_type->setObjectName(QStringLiteral("affichage_type"));
        affichage_type->setGeometry(QRect(890, 50, 113, 28));
        affichage_type->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        affichage_type->setReadOnly(true);
        tabWidget->addTab(tab_3, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        mdpU_new1 = new QLineEdit(tab);
        mdpU_new1->setObjectName(QStringLiteral("mdpU_new1"));
        mdpU_new1->setGeometry(QRect(330, 140, 113, 22));
        mdpU_new1->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpU_new1->setEchoMode(QLineEdit::Password);
        label_7 = new QLabel(tab);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(90, 140, 201, 20));
        label_7->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpU_new2 = new QLineEdit(tab);
        mdpU_new2->setObjectName(QStringLiteral("mdpU_new2"));
        mdpU_new2->setGeometry(QRect(330, 190, 113, 22));
        mdpU_new2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpU_new2->setEchoMode(QLineEdit::Password);
        label_8 = new QLabel(tab);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(10, 190, 291, 20));
        label_8->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpU_old = new QLineEdit(tab);
        mdpU_old->setObjectName(QStringLiteral("mdpU_old"));
        mdpU_old->setGeometry(QRect(330, 90, 113, 22));
        mdpU_old->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        mdpU_old->setEchoMode(QLineEdit::Password);
        label_9 = new QLabel(tab);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(110, 90, 181, 20));
        label_9->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        confirmer_reset = new QPushButton(tab);
        confirmer_reset->setObjectName(QStringLiteral("confirmer_reset"));
        confirmer_reset->setGeometry(QRect(340, 240, 93, 28));
        confirmer_reset->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        nomU_reset = new QLineEdit(tab);
        nomU_reset->setObjectName(QStringLiteral("nomU_reset"));
        nomU_reset->setGeometry(QRect(330, 40, 113, 22));
        nomU_reset->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        nomU_reset->setEchoMode(QLineEdit::Normal);
        label_10 = new QLabel(tab);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(140, 40, 151, 20));
        label_10->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        tabWidget->addTab(tab, QString());
        groupBox_11 = new QGroupBox(centralwidget);
        groupBox_11->setObjectName(QStringLiteral("groupBox_11"));
        groupBox_11->setGeometry(QRect(800, 10, 391, 41));
        groupBox_11->setStyleSheet(QStringLiteral("background-color: rgb(255, 222, 227);"));
        label_14 = new QLabel(groupBox_11);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(120, 0, 181, 41));
        QFont font;
        font.setFamily(QStringLiteral("Berlin Sans FB"));
        font.setPointSize(12);
        font.setBold(false);
        font.setItalic(false);
        font.setWeight(50);
        label_14->setFont(font);
        label_14->setStyleSheet(QStringLiteral("font: 12pt \"Berlin Sans FB\";"));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1400, 30));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "Nom d'utilisateur", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Mot De Passe", Q_NULLPTR));
        connexion->setText(QApplication::translate("MainWindow", "Connexion", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(Connexion), QApplication::translate("MainWindow", "Connexion", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Nom d'utilisateur", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Mot De Passe", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Email", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "Confirmer Mot De Passe", Q_NULLPTR));
        CreerCompte->setText(QApplication::translate("MainWindow", "Cr\303\251er compte", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "RFID", Q_NULLPTR));
        comboBox_type->clear();
        comboBox_type->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Admin", Q_NULLPTR)
         << QApplication::translate("MainWindow", "Employe", Q_NULLPTR)
        );
        label_12->setText(QApplication::translate("MainWindow", "Type", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Cr\303\251ation compte", Q_NULLPTR));
        supprimerU->setText(QApplication::translate("MainWindow", "Supprimer", Q_NULLPTR));
        modifierU->setText(QApplication::translate("MainWindow", "Modifier", Q_NULLPTR));
        label_matricule_rec_4->setText(QApplication::translate("MainWindow", "Email", Q_NULLPTR));
        label_type_rec_5->setText(QApplication::translate("MainWindow", "Nom d'utilisateur", Q_NULLPTR));
        refresh_users->setText(QApplication::translate("MainWindow", "Refresh", Q_NULLPTR));
        label_nom_rec_4->setText(QApplication::translate("MainWindow", "Mot de passe", Q_NULLPTR));
        label_nom_rec_5->setText(QApplication::translate("MainWindow", "RFID", Q_NULLPTR));
        label_type_rec_6->setText(QApplication::translate("MainWindow", "Type", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "Afficher Compte", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Nouveau Mot De Passe", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Confirmer Nouveau Mot De Passe", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "Ancien Mot De Passe", Q_NULLPTR));
        confirmer_reset->setText(QApplication::translate("MainWindow", "Confirmer", Q_NULLPTR));
        nomU_reset->setText(QString());
        label_10->setText(QApplication::translate("MainWindow", "Nom d'utilisateur", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "R\303\251initialiser Mode de passe", Q_NULLPTR));
        groupBox_11->setTitle(QString());
        label_14->setText(QApplication::translate("MainWindow", "  SMART RADIO", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
