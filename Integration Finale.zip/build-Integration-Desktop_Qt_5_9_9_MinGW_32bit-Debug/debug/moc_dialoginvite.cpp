/****************************************************************************
** Meta object code from reading C++ file 'dialoginvite.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Integrationsmart/dialoginvite.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialoginvite.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DialogInvite_t {
    QByteArrayData data[24];
    char stringdata0[459];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DialogInvite_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DialogInvite_t qt_meta_stringdata_DialogInvite = {
    {
QT_MOC_LITERAL(0, 0, 12), // "DialogInvite"
QT_MOC_LITERAL(1, 13, 24), // "on_pushButton_13_clicked"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 19), // "on_ajoutaff_clicked"
QT_MOC_LITERAL(4, 59, 25), // "on_confirmerajout_clicked"
QT_MOC_LITERAL(5, 85, 23), // "on_annulerajout_clicked"
QT_MOC_LITERAL(6, 109, 14), // "on_sup_clicked"
QT_MOC_LITERAL(7, 124, 23), // "on_confirmersup_clicked"
QT_MOC_LITERAL(8, 148, 16), // "on_modif_clicked"
QT_MOC_LITERAL(9, 165, 19), // "on_modifier_clicked"
QT_MOC_LITERAL(10, 185, 23), // "on_annulermodif_clicked"
QT_MOC_LITERAL(11, 209, 18), // "on_capture_clicked"
QT_MOC_LITERAL(12, 228, 31), // "on_comboBox_currentIndexChanged"
QT_MOC_LITERAL(13, 260, 5), // "index"
QT_MOC_LITERAL(14, 266, 24), // "on_pushButton_21_clicked"
QT_MOC_LITERAL(15, 291, 19), // "on_rech_textChanged"
QT_MOC_LITERAL(16, 311, 4), // "arg1"
QT_MOC_LITERAL(17, 316, 28), // "on_dateAjout_userDateChanged"
QT_MOC_LITERAL(18, 345, 4), // "date"
QT_MOC_LITERAL(19, 350, 21), // "on_calendrier_clicked"
QT_MOC_LITERAL(20, 372, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(21, 394, 27), // "on_dateEdit_userDateChanged"
QT_MOC_LITERAL(22, 422, 12), // "update_label"
QT_MOC_LITERAL(23, 435, 23) // "on_pushButton_2_clicked"

    },
    "DialogInvite\0on_pushButton_13_clicked\0"
    "\0on_ajoutaff_clicked\0on_confirmerajout_clicked\0"
    "on_annulerajout_clicked\0on_sup_clicked\0"
    "on_confirmersup_clicked\0on_modif_clicked\0"
    "on_modifier_clicked\0on_annulermodif_clicked\0"
    "on_capture_clicked\0on_comboBox_currentIndexChanged\0"
    "index\0on_pushButton_21_clicked\0"
    "on_rech_textChanged\0arg1\0"
    "on_dateAjout_userDateChanged\0date\0"
    "on_calendrier_clicked\0on_pushButton_clicked\0"
    "on_dateEdit_userDateChanged\0update_label\0"
    "on_pushButton_2_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DialogInvite[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  109,    2, 0x08 /* Private */,
       3,    0,  110,    2, 0x08 /* Private */,
       4,    0,  111,    2, 0x08 /* Private */,
       5,    0,  112,    2, 0x08 /* Private */,
       6,    0,  113,    2, 0x08 /* Private */,
       7,    0,  114,    2, 0x08 /* Private */,
       8,    0,  115,    2, 0x08 /* Private */,
       9,    0,  116,    2, 0x08 /* Private */,
      10,    0,  117,    2, 0x08 /* Private */,
      11,    0,  118,    2, 0x08 /* Private */,
      12,    1,  119,    2, 0x08 /* Private */,
      14,    0,  122,    2, 0x08 /* Private */,
      15,    1,  123,    2, 0x08 /* Private */,
      17,    1,  126,    2, 0x08 /* Private */,
      19,    0,  129,    2, 0x08 /* Private */,
      20,    0,  130,    2, 0x08 /* Private */,
      21,    1,  131,    2, 0x08 /* Private */,
      22,    0,  134,    2, 0x08 /* Private */,
      23,    0,  135,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   16,
    QMetaType::Void, QMetaType::QDate,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QDate,   18,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void DialogInvite::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        DialogInvite *_t = static_cast<DialogInvite *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_13_clicked(); break;
        case 1: _t->on_ajoutaff_clicked(); break;
        case 2: _t->on_confirmerajout_clicked(); break;
        case 3: _t->on_annulerajout_clicked(); break;
        case 4: _t->on_sup_clicked(); break;
        case 5: _t->on_confirmersup_clicked(); break;
        case 6: _t->on_modif_clicked(); break;
        case 7: _t->on_modifier_clicked(); break;
        case 8: _t->on_annulermodif_clicked(); break;
        case 9: _t->on_capture_clicked(); break;
        case 10: _t->on_comboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_pushButton_21_clicked(); break;
        case 12: _t->on_rech_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 13: _t->on_dateAjout_userDateChanged((*reinterpret_cast< const QDate(*)>(_a[1]))); break;
        case 14: _t->on_calendrier_clicked(); break;
        case 15: _t->on_pushButton_clicked(); break;
        case 16: _t->on_dateEdit_userDateChanged((*reinterpret_cast< const QDate(*)>(_a[1]))); break;
        case 17: _t->update_label(); break;
        case 18: _t->on_pushButton_2_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject DialogInvite::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_DialogInvite.data,
      qt_meta_data_DialogInvite,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *DialogInvite::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DialogInvite::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DialogInvite.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int DialogInvite::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
